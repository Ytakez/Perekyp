import { memo, useEffect, useRef } from "react";
import { toView } from "./logic";
import { createStage, type Stage } from "./phone3d";
import { endBoot, pick, useGame } from "./store";

let api: Stage | null = null;

export function focusView(which: "front" | "back" | "inside") {
  api?.focus(which);
}

export const StageView = memo(function StageView() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const stage = createStage(el, {
      onPick: (part, index) => pick(part, index),
      onBootEnd: (token) => endBoot(token),
    });
    api = stage;
    const push = () => {
      const s = useGame.getState();
      stage.setPhone(toView(s));
      stage.setBench(s.bench, s.boot, s.shake);
    };
    push();
    const unsub = useGame.subscribe(push);
    return () => {
      unsub();
      if (api === stage) api = null;
      stage.dispose();
    };
  }, []);
  return <div ref={ref} className="stage-view" />;
});
