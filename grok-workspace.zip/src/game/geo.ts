import * as THREE from "three";

/** Rounded rectangle in the XY plane, centered, counterclockwise. */
export function roundedRectShape(w: number, h: number, r: number) {
  const rr = Math.max(0.001, Math.min(r, w / 2 - 0.001, h / 2 - 0.001));
  const x = -w / 2;
  const y = -h / 2;
  const s = new THREE.Shape();
  s.moveTo(x + rr, y);
  s.lineTo(x + w - rr, y);
  s.absarc(x + w - rr, y + rr, rr, -Math.PI / 2, 0, false);
  s.lineTo(x + w, y + h - rr);
  s.absarc(x + w - rr, y + h - rr, rr, 0, Math.PI / 2, false);
  s.lineTo(x + rr, y + h);
  s.absarc(x + rr, y + h - rr, rr, Math.PI / 2, Math.PI, false);
  s.lineTo(x, y + rr);
  s.absarc(x + rr, y + rr, rr, Math.PI, Math.PI * 1.5, false);
  return s;
}

function holeFrom(shape: THREE.Shape) {
  const pts = shape.getPoints(40);
  const p = new THREE.Path();
  p.moveTo(pts[0].x, pts[0].y);
  for (let i = pts.length - 1; i > 0; i--) p.lineTo(pts[i].x, pts[i].y);
  return p;
}

/** Flat plate (glass, battery, shields). Extrudes along +Z and recenters. */
export function plateGeo(w: number, h: number, r: number, depth: number) {
  const shape = roundedRectShape(w, h, r);
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: depth > 0.01,
    bevelThickness: Math.min(0.004, depth * 0.25),
    bevelSize: Math.min(0.004, r * 0.15),
    bevelSegments: 1,
    curveSegments: 8,
  });
  geo.translate(0, 0, -depth / 2);
  geo.computeVertexNormals();
  return geo;
}

/** Hollow frame: rounded outer shell with a rounded window. */
export function frameGeo(w: number, h: number, r: number, wall: number, depth: number) {
  const outer = roundedRectShape(w, h, r);
  const inner = roundedRectShape(w - wall * 2, h - wall * 2, Math.max(0.012, r - wall));
  outer.holes.push(holeFrom(inner));
  const geo = new THREE.ExtrudeGeometry(outer, {
    depth,
    bevelEnabled: false,
    curveSegments: 10,
  });
  geo.translate(0, 0, -depth / 2);
  geo.computeVertexNormals();
  return geo;
}

export function shapeGeo(shape: THREE.Shape) {
  const geo = new THREE.ShapeGeometry(shape, 12);
  geo.computeVertexNormals();
  return geo;
}
