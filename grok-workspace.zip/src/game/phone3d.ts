import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { frameGeo, plateGeo, roundedRectShape, shapeGeo } from "./geo";
import { finishFor, layoutFor, type PhoneLayout } from "./layout";
import type { Bench, Boot, PhoneView } from "./types";

export type Stage = {
  setPhone(v: PhoneView | null): void;
  setBench(b: Bench, boot: Boot, shake: number): void;
  focus(which: "front" | "back" | "inside"): void;
  dispose(): void;
};

type Hooks = {
  onPick: (part: string, index?: number) => void;
  onBootEnd: (token: string) => void;
};

type Anchor = {
  id: string;
  part: string;
  index?: number;
  obj: THREE.Object3D;
  label: string;
  big: boolean;
};

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function canvasTex(c: HTMLCanvasElement) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

function paintScreen(ctx: CanvasRenderingContext2D, view: PhoneView, on: boolean, boot: Boot) {
  const w = 512;
  const h = 1024;
  ctx.clearRect(0, 0, w, h);
  const booting = !!(boot && performance.now() < boot.until);
  if (booting && boot) {
    ctx.fillStyle = "#07080c";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#f4f7fa";
    ctx.textAlign = "center";
    ctx.font = "600 36px Onest, sans-serif";
    ctx.fillText(boot.name, w / 2, h * 0.4);
    const p = Math.max(0, Math.min(1, 1 - (boot.until - performance.now()) / 2200));
    ctx.fillStyle = "#22262c";
    ctx.fillRect(w * 0.18, h * 0.48, w * 0.64, 16);
    ctx.fillStyle = boot.ok ? "#3ddc84" : "#ff5f6d";
    ctx.fillRect(w * 0.18, h * 0.48, w * 0.64 * p, 16);
    ctx.font = "500 22px Onest, sans-serif";
    ctx.fillStyle = "#9aa6b2";
    ctx.fillText(boot.ok ? "прошивка" : "сбой записи", w / 2, h * 0.56);
    return;
  }
  if (!on) {
    ctx.fillStyle = "#05060a";
    ctx.fillRect(0, 0, w, h);
  } else {
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, view.theme[0]);
    g.addColorStop(0.55, view.theme[1]);
    g.addColorStop(1, view.theme[2]);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    ctx.globalAlpha = 0.33;
    ctx.fillStyle = view.theme[3];
    ctx.beginPath();
    ctx.arc(w * 0.75, h * 0.18, 170, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.font = "700 84px Unbounded, sans-serif";
    ctx.fillText("09:41", w / 2, h * 0.3);
    ctx.font = "500 26px Onest, sans-serif";
    ctx.fillText("вторник, 27 октября", w / 2, h * 0.355);
    ctx.font = "600 22px Onest, sans-serif";
    ctx.fillText(view.romName, w / 2, h * 0.8);
  }
  if (view.d.s === 1 && on && !booting) {
    const shift = (performance.now() / 18) % 48;
    for (let y = shift; y < h; y += 34) {
      ctx.globalAlpha = 0.45;
      ctx.fillStyle = y % 68 < 34 ? "#39ff9a" : "#ff4d6d";
      ctx.fillRect(0, y, w, 3);
    }
    ctx.globalAlpha = 1;
  }
  if (view.d.s === 2 || view.c === 3) {
    const rnd = mulberry(view.id * 17 + 3);
    const stroke = (color: string, width: number) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      ctx.lineCap = "round";
      for (let n = 0; n < 3; n++) {
        let x = w * (0.35 + rnd() * 0.3);
        let y = h * (0.28 + rnd() * 0.2);
        ctx.beginPath();
        ctx.moveTo(x, y);
        for (let i = 0; i < 6; i++) {
          x += (rnd() - 0.45) * 110;
          y += 30 + rnd() * 70;
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    };
    stroke("rgba(0,0,0,.65)", 7);
    stroke("rgba(255,255,255,.8)", 2);
  }
}

function paintPcb(ctx: CanvasRenderingContext2D, seed: number, water: boolean) {
  const w = 512;
  const h = 512;
  const rnd = mulberry(seed);
  ctx.fillStyle = "#146b34";
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = "#0c4e26";
  ctx.lineWidth = 2;
  for (let i = 0; i < 36; i++) {
    ctx.beginPath();
    let x = rnd() * w;
    let y = rnd() * h;
    ctx.moveTo(x, y);
    for (let k = 0; k < 4; k++) {
      x += (rnd() - 0.5) * 90;
      y += (rnd() - 0.5) * 50;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  ctx.fillStyle = "#d6b25e";
  for (let i = 0; i < 26; i++) ctx.fillRect(rnd() * w, rnd() * h, 10, 6);
  ctx.fillStyle = "rgba(255,255,255,.85)";
  ctx.font = "700 32px Unbounded, sans-serif";
  ctx.fillText("BOARD", 28, 52);
  ctx.font = "18px Onest, sans-serif";
  ctx.fillText("SOC   RAM   PMIC   RF", 28, 84);
  if (water) {
    ctx.fillStyle = "rgba(232,236,220,.62)";
    for (let i = 0; i < 7; i++) {
      ctx.beginPath();
      ctx.arc(rnd() * w, rnd() * h, 18 + rnd() * 36, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function paintBat(ctx: CanvasRenderingContext2D, mah: number, swollen: boolean) {
  ctx.fillStyle = "#101114";
  ctx.fillRect(0, 0, 512, 280);
  ctx.strokeStyle = swollen ? "#ffb020" : "#d5d8de";
  ctx.lineWidth = 6;
  ctx.strokeRect(16, 16, 480, 248);
  ctx.fillStyle = swollen ? "#ffb020" : "#f2f4f8";
  ctx.font = "700 48px Unbounded, sans-serif";
  ctx.fillText(swollen ? "ВЗДУТА" : "АКБ", 36, 88);
  ctx.fillStyle = "#d5d8de";
  ctx.font = "28px Onest, sans-serif";
  ctx.fillText(`${mah} mAh    3.87 V`, 36, 140);
  ctx.font = "20px Onest, sans-serif";
  ctx.fillText("LI-PO  ·  НЕ ГНУТЬ  ·  НЕ ПРОКАЛЫВАТЬ", 36, 184);
  ctx.fillStyle = "#e8e8e8";
  let x = 36;
  for (let i = 0; i < 42; i++) {
    const bw = 2 + (i % 3);
    if (i % 2 === 0) ctx.fillRect(x, 206, bw, 32);
    x += bw + 1;
  }
}

function paintScratch(ctx: CanvasRenderingContext2D, seed: number) {
  ctx.clearRect(0, 0, 512, 1024);
  const rnd = mulberry(seed);
  ctx.strokeStyle = "rgba(255,255,255,.75)";
  ctx.lineWidth = 2;
  ctx.lineCap = "round";
  for (let i = 0; i < 7; i++) {
    ctx.beginPath();
    let x = rnd() * 512;
    let y = rnd() * 1024;
    ctx.moveTo(x, y);
    for (let k = 0; k < 3; k++) {
      x += (rnd() - 0.25) * 140;
      y += (rnd() - 0.5) * 30;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
}

function cylZ(r: number, height: number, seg = 24) {
  const g = new THREE.CylinderGeometry(r, r, height, seg);
  g.rotateX(Math.PI / 2);
  return g;
}

export function createStage(host: HTMLElement, hooks: Hooks): Stage {
  const reduce = typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const canvas = document.createElement("canvas");
  const layer = document.createElement("div");
  layer.className = "hot-layer";
  host.appendChild(canvas);
  host.appendChild(layer);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0x12161c, 1);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x12161c);
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex;

  const camera = new THREE.PerspectiveCamera(34, 1, 0.05, 30);
  camera.position.set(0.45, 0.32, 3.15);

  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.autoRotate = !reduce;
  controls.autoRotateSpeed = 0.65;
  controls.enablePan = false;
  controls.minDistance = 1.55;
  controls.maxDistance = 6.5;
  controls.maxPolarAngle = Math.PI * 0.92;
  controls.minPolarAngle = 0.22;
  controls.target.set(0, 0, 0);

  scene.add(new THREE.HemisphereLight(0xe7eef8, 0x2a2420, 0.65));
  const key = new THREE.DirectionalLight(0xfff6ec, 2.5);
  key.position.set(1.8, 3.4, 2.2);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.4;
  key.shadow.camera.far = 8;
  key.shadow.camera.left = -1.4;
  key.shadow.camera.right = 1.4;
  key.shadow.camera.top = 1.4;
  key.shadow.camera.bottom = -1.4;
  key.shadow.bias = -0.0006;
  scene.add(key);
  scene.add(key.target);
  const fill = new THREE.DirectionalLight(0xb9c8e4, 0.85);
  fill.position.set(-2.4, 1.4, -1.2);
  scene.add(fill);
  const rim = new THREE.DirectionalLight(0xffffff, 1.15);
  rim.position.set(-0.4, 1.2, -3.2);
  scene.add(rim);

  const matCanvas = document.createElement("canvas");
  matCanvas.width = 512;
  matCanvas.height = 512;
  const mg = matCanvas.getContext("2d")!;
  mg.fillStyle = "#1b3d36";
  mg.fillRect(0, 0, 512, 512);
  mg.strokeStyle = "#2e6658";
  mg.lineWidth = 2;
  for (let i = 0; i <= 512; i += 32) {
    mg.beginPath();
    mg.moveTo(i, 0);
    mg.lineTo(i, 512);
    mg.stroke();
    mg.beginPath();
    mg.moveTo(0, i);
    mg.lineTo(512, i);
    mg.stroke();
  }
  const matMap = canvasTex(matCanvas);
  matMap.wrapS = matMap.wrapT = THREE.RepeatWrapping;
  matMap.repeat.set(3, 3);
  const desk = new THREE.Mesh(
    new THREE.CircleGeometry(2.6, 48),
    new THREE.MeshStandardMaterial({ map: matMap, roughness: 0.92, metalness: 0 }),
  );
  desk.rotation.x = -Math.PI / 2;
  desk.position.y = -0.85;
  desk.receiveShadow = true;
  scene.add(desk);

  const timer = new THREE.Timer();
  timer.connect(document);
  const ray = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const tmp = new THREE.Vector3();
  const forward = new THREE.Vector3();
  const ndc = new THREE.Vector3();
  const fly = new THREE.Vector3();

  let view: PhoneView | null = null;
  let bench: Bench = { mode: "own", phoneId: null, tool: "hand", screwsIn: [true, true, true, true], open: false, batConn: true };
  let boot: Boot = null;
  let dead = false;
  let flying = false;
  let openAmt = 0;
  let flexAmt = 0;
  let shakeAmt = 0;
  let lastShake = 0;
  let bootToken = "";
  let bootSent = false;
  let screenDirty = true;
  let idle = 0;
  let builtSig = "";
  let phoneRoot: THREE.Group | null = null;
  let cover: THREE.Group | null = null;
  let screenG: THREE.Group | null = null;
  let flexMesh: THREE.Object3D | null = null;
  let flexHome = new THREE.Vector3();
  let screws: THREE.Object3D[] = [];
  let screwHome: THREE.Vector3[] = [];
  let screwT: number[] = [];
  let anchors: Anchor[] = [];
  let opensFront = false;
  let swell = 0;
  let backPos = new THREE.Vector3(0.45, 0.32, 3.15);
  let frontPos = new THREE.Vector3(0.4, 0.28, -3.15);
  let insidePos = new THREE.Vector3(0.2, 0.55, 2.4);
  let screenCtx: CanvasRenderingContext2D | null = null;
  let screenTexture: THREE.CanvasTexture | null = null;
  const geos = new Set<THREE.BufferGeometry>();
  const mats = new Set<THREE.Material>();
  const texs = new Set<THREE.Texture>();
  const buttons = new Map<string, HTMLButtonElement>();

  function trackGeo(g: THREE.BufferGeometry) {
    geos.add(g);
    return g;
  }
  function trackMat<T extends THREE.Material>(m: T) {
    mats.add(m);
    return m;
  }
  function trackTex(t: THREE.Texture) {
    texs.add(t);
    return t;
  }
  function useMesh<T extends THREE.Mesh>(mesh: T, shadow = true) {
    trackGeo(mesh.geometry);
    const material = mesh.material;
    if (Array.isArray(material)) material.forEach((m) => mats.add(m));
    else mats.add(material);
    mesh.castShadow = shadow;
    return mesh;
  }
  function tag(obj: THREE.Object3D, part: string, index?: number) {
    obj.traverse((c) => {
      if (!c.userData.part) {
        c.userData.part = part;
        if (index != null) c.userData.index = index;
      }
    });
  }
  function anchor(obj: THREE.Object3D, id: string, part: string, label: string, big: boolean, index?: number) {
    anchors.push({ id, part, index, obj, label, big });
  }

  function clearPhone() {
    if (phoneRoot) scene.remove(phoneRoot);
    phoneRoot = null;
    cover = null;
    screenG = null;
    flexMesh = null;
    screws = [];
    screwHome = [];
    screwT = [];
    anchors = [];
    geos.forEach((g) => g.dispose());
    mats.forEach((m) => m.dispose());
    texs.forEach((t) => t.dispose());
    geos.clear();
    mats.clear();
    texs.clear();
    screenCtx = null;
    screenTexture = null;
    builtSig = "";
    for (const b of buttons.values()) b.remove();
    buttons.clear();
  }

  function viewVec(dist: number, x: number, y: number, z: number) {
    return new THREE.Vector3(x, y, z).setLength(dist);
  }

  function build(v: PhoneView) {
    clearPhone();
    builtSig = v.sig;
    const L = layoutFor(v.brand, v.model, v.base);
    const fin = finishFor(v.brand, v.model, v.color);
    opensFront = L.opensFront;
    swell = v.d.b ? 0.016 : 0;
    const dist = Math.max(2.85, L.h * 1.92);
    backPos = viewVec(dist, 0.42, 0.3, 1);
    frontPos = viewVec(dist, 0.36, 0.26, -1);
    insidePos = viewVec(Math.max(2.35, L.h * 1.55), 0.12, 0.62, opensFront ? -1 : 1);
    desk.position.y = -L.h / 2 - 0.02;

    const fake = v.fakeSeen;
    const metal = trackMat(
      new THREE.MeshStandardMaterial({
        color: fin.frame,
        metalness: fake ? 0.25 : 0.92,
        roughness: fake ? 0.58 : v.c >= 2 ? 0.38 : 0.26,
        envMapIntensity: 1.05,
      }),
    );
    const glassMat = trackMat(
      new THREE.MeshPhysicalMaterial({
        color: fin.glass,
        metalness: 0.04,
        roughness: v.c >= 2 ? 0.28 : 0.1,
        clearcoat: 1,
        clearcoatRoughness: 0.12,
        envMapIntensity: 1.1,
        transparent: L.glyph,
        opacity: L.glyph ? 0.46 : 1,
      }),
    );
    const dark = trackMat(new THREE.MeshStandardMaterial({ color: 0x121418, roughness: 0.55, metalness: 0.15 }));
    const brass = trackMat(new THREE.MeshStandardMaterial({ color: 0xc6a15a, metalness: 0.8, roughness: 0.32 }));
    const orange = trackMat(new THREE.MeshStandardMaterial({ color: 0xc45c26, roughness: 0.55, metalness: 0.15 }));
    const copper = trackMat(new THREE.MeshStandardMaterial({ color: 0xb87333, metalness: 0.75, roughness: 0.32 }));
    const lensMat = trackMat(
      new THREE.MeshPhysicalMaterial({
        color: 0x0c1422,
        metalness: 0.15,
        roughness: 0.04,
        clearcoat: 1,
        clearcoatRoughness: 0.05,
      }),
    );
    const ghost = trackMat(new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));

    const root = new THREE.Group();
    phoneRoot = root;
    scene.add(root);

    const frame = useMesh(new THREE.Mesh(trackGeo(frameGeo(L.w, L.h, L.radius, L.wall, L.d)), metal));
    root.add(frame);

    const face = L.opensFront ? -1 : 1;
    const pretty = (lift: number) => face * (0.006 + lift);
    const backZ = L.opensFront ? 0.02 : -0.02;
    const innerW = L.w - L.wall * 2 - 0.02;
    const innerH = L.h - L.wall * 2 - 0.02;
    root.add(useMesh(new THREE.Mesh(trackGeo(plateGeo(innerW, innerH, Math.max(0.02, L.radius - L.wall), 0.008)), dark)));
    const backdrop = root.children[root.children.length - 1];
    backdrop.position.z = backZ;

    const coverG = new THREE.Group();
    cover = coverG;
    root.add(coverG);
    const glass = useMesh(
      new THREE.Mesh(trackGeo(plateGeo(L.w - 0.012, L.h - 0.012, Math.max(0.02, L.radius - 0.006), 0.012)), glassMat),
    );
    glass.position.z = L.d / 2 - 0.001;
    coverG.add(glass);
    tag(coverG, "cover");

    if (v.c >= 2) {
      const sc = document.createElement("canvas");
      sc.width = 512;
      sc.height = 1024;
      paintScratch(sc.getContext("2d")!, v.id);
      const st = trackTex(canvasTex(sc));
      const scratch = useMesh(
        new THREE.Mesh(
          trackGeo(shapeGeo(roundedRectShape(L.w - 0.04, L.h - 0.04, L.radius * 0.8))),
          trackMat(new THREE.MeshBasicMaterial({ map: st, transparent: true, opacity: 0.45, depthWrite: false })),
        ),
        false,
      );
      scratch.position.z = L.d / 2 + 0.008;
      coverG.add(scratch);
    }

    if (L.glyph) {
      const film = useMesh(new THREE.Mesh(trackGeo(plateGeo(innerW * 0.86, innerH * 0.72, 0.04, 0.004)), dark), false);
      film.position.set(0, -0.05, L.d / 2 - 0.012);
      coverG.add(film);
      const glow = trackMat(new THREE.MeshStandardMaterial({ color: 0xf5f5f5, emissive: 0xf4f7fb, emissiveIntensity: 0.9, roughness: 0.4 }));
      for (const [x, y, ww, hh] of [
        [-0.12, -0.15, 0.16, 0.012],
        [0.05, -0.02, 0.22, 0.012],
        [-0.02, 0.12, 0.1, 0.012],
        [0.12, -0.28, 0.14, 0.012],
      ] as const) {
        const bar = useMesh(new THREE.Mesh(new THREE.BoxGeometry(ww, hh, 0.004), glow), false);
        bar.position.set(x, y, L.d / 2 - 0.008);
        coverG.add(bar);
      }
    }

    const cam = L.cam;
    const islandZ = L.d / 2 + 0.008;
    const islandMat = trackMat(
      new THREE.MeshPhysicalMaterial({
        color: L.poco ? fin.accent : fin.glass,
        metalness: L.poco ? 0.2 : 0.08,
        roughness: 0.22,
        clearcoat: 1,
        clearcoatRoughness: 0.2,
        emissive: L.poco ? fin.accent : 0x000000,
        emissiveIntensity: L.poco ? 0.15 : 0,
      }),
    );
    let island: THREE.Mesh;
    if (cam.shape === "single" || cam.shape === "circle") {
      island = useMesh(new THREE.Mesh(trackGeo(cylZ(cam.r, 0.014, 32)), islandMat));
    } else {
      island = useMesh(new THREE.Mesh(trackGeo(plateGeo(cam.w, cam.h, cam.r, 0.012)), islandMat));
    }
    island.position.set(cam.x, cam.y, islandZ);
    coverG.add(island);
    cam.lenses.forEach((lens, i) => {
      const ox = fake && i === 0 ? 0.012 : 0;
      const ring = useMesh(new THREE.Mesh(trackGeo(cylZ(lens.r * 1.08, 0.01, 28)), metal));
      ring.position.set(lens.x + ox, lens.y, islandZ + 0.006);
      coverG.add(ring);
      const well = useMesh(new THREE.Mesh(trackGeo(cylZ(lens.r * 0.86, 0.012, 28)), dark));
      well.position.set(lens.x + ox, lens.y, islandZ + 0.01);
      coverG.add(well);
      const glassL = useMesh(new THREE.Mesh(trackGeo(cylZ(lens.r * 0.62, 0.006, 28)), lensMat));
      glassL.position.set(lens.x + ox, lens.y, islandZ + 0.014);
      coverG.add(glassL);
      const glint = useMesh(
        new THREE.Mesh(
          trackGeo(cylZ(lens.r * 0.16, 0.004, 12)),
          trackMat(new THREE.MeshStandardMaterial({ color: 0x8fb4d8, emissive: 0x6a90b0, emissiveIntensity: 0.4, roughness: 0.2 })),
        ),
        false,
      );
      glint.position.set(lens.x + ox - lens.r * 0.15, lens.y + lens.r * 0.12, islandZ + 0.018);
      coverG.add(glint);
    });
    if (cam.flash) {
      const fl = useMesh(
        new THREE.Mesh(
          trackGeo(cylZ(0.012, 0.008, 16)),
          trackMat(new THREE.MeshStandardMaterial({ color: 0xfff1d2, emissive: 0xffe2a8, emissiveIntensity: 0.35, roughness: 0.3 })),
        ),
        false,
      );
      fl.position.set(cam.flash.x, cam.flash.y, islandZ + 0.012);
      coverG.add(fl);
    }
    if (L.hinge) {
      const hinge = useMesh(new THREE.Mesh(new THREE.BoxGeometry(L.w - 0.04, 0.012, 0.008), dark), false);
      hinge.position.set(0, 0, L.d / 2 + 0.01);
      coverG.add(hinge);
    }
    tag(coverG, "cover");
    anchor(coverG, "cover", "cover", opensFront ? "Экран" : "Крышка", true);

    const scr = new THREE.Group();
    screenG = scr;
    root.add(scr);
    const screenW = L.front === "home" ? L.w - 0.11 : L.w - L.wall * 2 - 0.02;
    const screenH = L.front === "home" ? L.h * 0.66 : L.h - L.wall * 2 - 0.025;
    const screenY = L.front === "home" ? 0.1 : 0;
    const sc = document.createElement("canvas");
    sc.width = 512;
    sc.height = 1024;
    screenCtx = sc.getContext("2d");
    screenTexture = trackTex(canvasTex(sc));
    const screenMat = trackMat(
      new THREE.MeshStandardMaterial({
        map: screenTexture,
        emissive: 0xffffff,
        emissiveMap: screenTexture,
        emissiveIntensity: 0.85,
        roughness: 0.42,
        metalness: 0,
      }),
    );
    const screen = useMesh(
      new THREE.Mesh(trackGeo(shapeGeo(roundedRectShape(screenW, screenH, L.front === "home" ? 0.04 : L.radius * 0.72))), screenMat),
      false,
    );
    screen.position.set(0, screenY, -L.d / 2 - 0.002);
    screen.rotation.y = Math.PI;
    scr.add(screen);
    const bezel = useMesh(new THREE.Mesh(trackGeo(plateGeo(screenW + 0.02, screenH + 0.02, L.radius * 0.7, 0.008)), dark), false);
    bezel.position.set(0, screenY, -L.d / 2 + 0.006);
    scr.add(bezel);
    if (L.front === "island") {
      const isle = useMesh(new THREE.Mesh(trackGeo(plateGeo(0.28, 0.072, 0.036, 0.008)), dark), false);
      isle.position.set(0, L.h / 2 - 0.16, -L.d / 2 - 0.008);
      scr.add(isle);
    } else if (L.front === "notch") {
      const notch = useMesh(new THREE.Mesh(trackGeo(plateGeo(0.34, 0.09, 0.03, 0.01)), dark), false);
      notch.position.set(0, screenY + screenH / 2 - 0.02, -L.d / 2 - 0.006);
      scr.add(notch);
    } else if (L.front === "punch") {
      const punch = useMesh(new THREE.Mesh(trackGeo(cylZ(0.02, 0.008, 20)), dark), false);
      punch.position.set(0, screenY + screenH / 2 - 0.08, -L.d / 2 - 0.008);
      scr.add(punch);
    } else {
      const home = useMesh(new THREE.Mesh(trackGeo(cylZ(0.055, 0.008, 28)), metal), false);
      home.position.set(0, -L.h / 2 + 0.16, -L.d / 2 - 0.004);
      const dot = useMesh(new THREE.Mesh(trackGeo(cylZ(0.018, 0.004, 16)), dark), false);
      dot.position.set(0, -L.h / 2 + 0.16, -L.d / 2 - 0.009);
      scr.add(home, dot);
    }
    tag(scr, "screen");
    anchor(screen, "screen", "screen", "Экран", false);

    const volMat = metal;
    const btnGeo = trackGeo(new THREE.CapsuleGeometry(0.011, 0.06, 2, 8));
    const powerGeo = trackGeo(new THREE.CapsuleGeometry(0.011, 0.09, 2, 8));
    for (const y of [0.16, 0.05]) {
      const b = useMesh(new THREE.Mesh(btnGeo, volMat));
      b.position.set(-L.w / 2 - 0.001, y, 0);
      root.add(b);
    }
    const power = useMesh(new THREE.Mesh(powerGeo, volMat));
    power.position.set(L.w / 2 + 0.001, 0.12, 0);
    root.add(power);
    if (L.rog) {
      const rgb = useMesh(
        new THREE.Mesh(
          new THREE.BoxGeometry(0.008, L.h * 0.45, 0.012),
          trackMat(new THREE.MeshStandardMaterial({ color: 0xff2a2a, emissive: 0xff1a1a, emissiveIntensity: 0.8 })),
        ),
        false,
      );
      rgb.position.set(L.w / 2 + 0.002, -0.15, 0.02);
      root.add(rgb);
    }
    if (L.opensFront && L.front !== "home") {
      const plastic = trackMat(new THREE.MeshStandardMaterial({ color: 0x1a1c20, roughness: 0.7, metalness: 0 }));
      for (const y of [L.h * 0.3, -L.h * 0.24]) {
        for (const side of [-1, 1]) {
          const band = useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.014, L.d * 0.72), plastic), false);
          band.position.set(side * (L.w / 2), y, 0);
          root.add(band);
        }
      }
    }
    const portW = L.port === "lightning" ? 0.07 : 0.09;
    const port = useMesh(new THREE.Mesh(new THREE.BoxGeometry(portW, 0.01, 0.02), dark), false);
    port.position.set(0, -L.h / 2 + 0.002, 0);
    root.add(port);
    const tongue = useMesh(
      new THREE.Mesh(new THREE.BoxGeometry(portW * 0.55, 0.004, 0.01), metal),
      false,
    );
    tongue.position.set(0, -L.h / 2 + 0.002, 0);
    root.add(tongue);
    for (const x of [-0.13, 0.13]) {
      const slit = useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.007, 0.012), dark), false);
      slit.position.set(x, -L.h / 2 + 0.002, 0.012);
      root.add(slit);
    }

    const screwPos: THREE.Vector3[] = [];
    if (L.screws === 2) {
      const z = L.d / 2 + 0.012;
      screwPos.push(new THREE.Vector3(-0.15, -L.h / 2 + 0.075, z), new THREE.Vector3(0.15, -L.h / 2 + 0.075, z));
    } else {
      const z = L.d / 2 + 0.012;
      const ix = L.w / 2 - 0.058;
      const iy = L.h / 2 - 0.075;
      screwPos.push(new THREE.Vector3(-ix, iy, z), new THREE.Vector3(ix, iy, z), new THREE.Vector3(-ix, -iy, z), new THREE.Vector3(ix, -iy, z));
    }
    screwPos.forEach((p, i) => {
      const g = new THREE.Group();
      const headMat = trackMat(brass.clone());
      const head = useMesh(new THREE.Mesh(trackGeo(cylZ(0.016, 0.008, 20)), headMat));
      g.add(head);
      if (L.screws === 2) {
        for (let k = 0; k < 5; k++) {
          const dot = useMesh(new THREE.Mesh(trackGeo(cylZ(0.0024, 0.004, 8)), dark), false);
          const a = (k / 5) * Math.PI * 2;
          dot.position.set(Math.cos(a) * 0.006, Math.sin(a) * 0.006, 0.005);
          g.add(dot);
        }
      } else {
        const slotH = useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.0035, 0.003), dark), false);
        const slotV = useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.0035, 0.02, 0.003), dark), false);
        slotH.position.z = 0.005;
        slotV.position.z = 0.005;
        g.add(slotH, slotV);
      }
      const hit = useMesh(new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), ghost), false);
      g.add(hit);
      g.position.copy(p);
      tag(g, "screw", i);
      root.add(g);
      screws.push(g);
      screwHome.push(p.clone());
      screwT.push(0);
      anchor(g, "screw" + i, "screw", "Винт", true, i);
    });

    buildInsides(root, L, v, pretty, {
      useMesh, trackGeo, trackMat, trackTex, tag, anchor, dark, metal, orange, copper, brass,
    });

    screenDirty = true;
  }

  function buildInsides(
    root: THREE.Group,
    L: PhoneLayout,
    v: PhoneView,
    pretty: (lift: number) => number,
    kit: {
      useMesh: typeof useMesh;
      trackGeo: typeof trackGeo;
      trackMat: typeof trackMat;
      trackTex: typeof trackTex;
      tag: typeof tag;
      anchor: typeof anchor;
      dark: THREE.Material;
      metal: THREE.Material;
      orange: THREE.Material;
      copper: THREE.Material;
      brass: THREE.Material;
    },
  ) {
    const pcbC = document.createElement("canvas");
    pcbC.width = 512;
    pcbC.height = 512;
    paintPcb(pcbC.getContext("2d")!, v.id * 13 + 9, v.d.w === 1 || (v.d.f === 1 && v.id % 3 === 0));
    const pcbTex = kit.trackTex(canvasTex(pcbC));
    const pcbMat = kit.trackMat(
      new THREE.MeshStandardMaterial({ map: pcbTex, roughness: 0.62, metalness: 0.12, color: 0xffffff }),
    );
    const shieldMat = kit.trackMat(new THREE.MeshStandardMaterial({ color: 0xc5c8ce, metalness: 0.82, roughness: 0.34 }));
    const chipMat = kit.trackMat(new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: 0.45, metalness: 0.35 }));

    let bw: number;
    let bh: number;
    let bx: number;
    let by: number;
    let boardMesh: THREE.Object3D;

    if (L.board === "L") {
      const left = -L.w / 2 + L.wall + 0.03;
      const right = L.w / 2 - L.wall - 0.03;
      const top = L.h / 2 - L.wall - 0.05;
      const bot = -L.h / 2 + L.wall + 0.1;
      const midY = -L.h * 0.05;
      const stemX = left + (right - left) * 0.48;
      const shape = new THREE.Shape();
      shape.moveTo(left, midY);
      shape.lineTo(left, top);
      shape.lineTo(right, top);
      shape.lineTo(right, bot);
      shape.lineTo(stemX, bot);
      shape.lineTo(stemX, midY);
      shape.closePath();
      boardMesh = kit.useMesh(new THREE.Mesh(kit.trackGeo(shapeGeo(shape)), pcbMat), false);
      boardMesh.position.z = pretty(0);
      if (L.opensFront) boardMesh.rotation.y = Math.PI;
      bw = stemX - left - 0.03;
      bh = midY - bot - 0.03;
      bx = (left + stemX) / 2;
      by = (bot + midY) / 2 - 0.01;
      const soc = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.16, 0.01), shieldMat));
      soc.position.set((left + right) / 2 - 0.02, (midY + top) / 2, pretty(0.012));
      kit.tag(soc, "soc");
      kit.anchor(soc, "soc", "soc", "Чип", false);
      root.add(soc);
      const nand = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.008), shieldMat));
      nand.position.set(stemX + 0.06, (midY + bot) / 2, pretty(0.01));
      root.add(nand);
    } else {
      const pw = L.w - L.wall * 2 - 0.06;
      const ph = L.h * 0.34;
      const py = L.h * 0.2;
      boardMesh = kit.useMesh(new THREE.Mesh(kit.trackGeo(shapeGeo(roundedRectShape(pw, ph, 0.04))), pcbMat), false);
      boardMesh.position.set(0, py, pretty(0));
      if (L.opensFront) boardMesh.rotation.y = Math.PI;
      bw = L.w - L.wall * 2 - 0.08;
      bh = L.h * 0.4;
      bx = 0;
      by = -L.h * 0.16;
      const soc = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.16, 0.01), shieldMat));
      soc.position.set(-0.06, py + 0.02, pretty(0.012));
      kit.tag(soc, "soc");
      kit.anchor(soc, "soc", "soc", "Чип", false);
      root.add(soc);
      const nand = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.09, 0.008), shieldMat));
      nand.position.set(0.12, py - 0.04, pretty(0.01));
      root.add(nand);
      const pmic = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.006), chipMat), false);
      pmic.position.set(0.02, py + 0.08, pretty(0.01));
      root.add(pmic);
      const daughter = kit.useMesh(
        new THREE.Mesh(kit.trackGeo(plateGeo(L.w * 0.55, 0.07, 0.015, 0.006)), pcbMat),
        false,
      );
      daughter.position.set(0, -L.h / 2 + L.wall + 0.08, pretty(0));
      root.add(daughter);
    }
    kit.tag(boardMesh, "board");
    kit.anchor(boardMesh, "board", "board", "Плата", false);
    root.add(boardMesh);

    const caps = new THREE.InstancedMesh(
      kit.trackGeo(new THREE.BoxGeometry(0.014, 0.007, 0.004)),
      kit.trackMat(new THREE.MeshStandardMaterial({ color: 0xc4a574, roughness: 0.48, metalness: 0.25 })),
      26,
    );
    mats.add(caps.material as THREE.Material);
    const dummy = new THREE.Object3D();
    const rnd = mulberry(v.id * 9 + 4);
    for (let i = 0; i < 26; i++) {
      dummy.position.set((rnd() - 0.5) * (L.w * 0.55), L.h * 0.12 + (rnd() - 0.5) * L.h * 0.22, pretty(0.014));
      dummy.rotation.z = rnd() * 0.5;
      dummy.updateMatrix();
      caps.setMatrixAt(i, dummy.matrix);
    }
    caps.instanceMatrix.needsUpdate = true;
    root.add(caps);

    const batBody = kit.useMesh(
      new THREE.Mesh(
        kit.trackGeo(plateGeo(Math.max(0.12, bw), Math.max(0.12, bh), 0.03, 0.028)),
        kit.trackMat(new THREE.MeshStandardMaterial({ color: v.d.b ? 0x2a2418 : 0x14161a, roughness: 0.72, metalness: 0.05 })),
      ),
    );
    batBody.position.set(bx, by, pretty(0.004));
    if (v.d.b) batBody.scale.z = 1.45;
    const batC = document.createElement("canvas");
    batC.width = 512;
    batC.height = 280;
    paintBat(batC.getContext("2d")!, 2800 + Math.round(v.base / 35), v.d.b === 1);
    const batTex = kit.trackTex(canvasTex(batC));
    const label = kit.useMesh(
      new THREE.Mesh(
        new THREE.PlaneGeometry(Math.max(0.1, bw) * 0.86, Math.max(0.08, bh) * 0.62),
        kit.trackMat(new THREE.MeshStandardMaterial({ map: batTex, roughness: 0.7, metalness: 0 })),
      ),
      false,
    );
    label.position.set(bx, by, pretty(0.02));
    if (L.opensFront) label.rotation.y = Math.PI;
    const bat = new THREE.Group();
    bat.add(batBody);
    bat.add(label);
    kit.tag(bat, "battery");
    kit.anchor(bat, "battery", "battery", "АКБ", false);
    root.add(bat);

    if (v.base > 40000 && L.front !== "home") {
      const coil = kit.useMesh(
        new THREE.Mesh(new THREE.TorusGeometry(Math.min(bw, bh) * 0.33, 0.0045, 6, 28), kit.copper),
        false,
      );
      coil.position.set(bx, by, pretty(0.022));
      root.add(coil);
    }

    const flex = new THREE.Group();
    const tail = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.09, 0.004), kit.orange));
    const plug = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, 0.006), kit.trackMat(new THREE.MeshStandardMaterial({ color: 0xd4b15a, metalness: 0.7, roughness: 0.3 }))));
    plug.position.y = 0.05;
    const hit = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.12, 0.03), kit.trackMat(new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }))), false);
    flex.add(tail, plug, hit);
    flex.position.set(bx + bw * 0.28, by + bh * 0.42, pretty(0.012));
    flexHome = flex.position.clone();
    flexMesh = flex;
    kit.tag(flex, "flex");
    kit.anchor(flex, "flex", "flex", "Шлейф", true);
    root.add(flex);

    L.cam.lenses.forEach((lens) => {
      const mod = kit.useMesh(new THREE.Mesh(trackGeo(cylZ(lens.r * 0.9, 0.016, 20)), chipMat));
      mod.position.set(lens.x, lens.y, pretty(0.012));
      root.add(mod);
    });

    const speaker = kit.useMesh(new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.04, 0.012), kit.dark));
    speaker.position.set(0, -L.h / 2 + L.wall + 0.07, pretty(0.006));
    root.add(speaker);
    const motor = kit.useMesh(new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.03, 12), kit.metal));
    motor.rotation.z = Math.PI / 2;
    motor.position.set(-L.w * 0.22, -L.h / 2 + L.wall + 0.09, pretty(0.008));
    root.add(motor);

    for (const [x, y] of [
      [-1, 1],
      [1, 1],
      [-1, -1],
      [1, -1],
    ] as const) {
      const post = kit.useMesh(new THREE.Mesh(trackGeo(cylZ(0.012, 0.02, 10)), kit.brass), false);
      post.position.set(x * (L.w / 2 - L.wall - 0.02), y * (L.h / 2 - L.wall - 0.05), pretty(0));
      root.add(post);
    }
  }

  function flyTo(v: THREE.Vector3) {
    fly.copy(v);
    flying = true;
    controls.autoRotate = false;
  }

  function resize() {
    const w = host.clientWidth;
    const h = host.clientHeight;
    if (w < 2 || h < 2) return;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(resize);
  ro.observe(host);
  resize();

  let downX = 0;
  let downY = 0;
  const onDown = (e: PointerEvent) => {
    downX = e.clientX;
    downY = e.clientY;
    flying = false;
    controls.autoRotate = false;
    idle = 0;
  };
  const onUp = (e: PointerEvent) => {
    idle = 0.001;
    if (e.target !== canvas) return;
    if (Math.hypot(e.clientX - downX, e.clientY - downY) > 8) return;
    if (!phoneRoot) return;
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    ray.setFromCamera(pointer, camera);
    const hits = ray.intersectObject(phoneRoot, true);
    for (const h of hits) {
      let o: THREE.Object3D | null = h.object;
      while (o && !o.userData.part) o = o.parent;
      if (o?.userData.part) {
        hooks.onPick(String(o.userData.part), o.userData.index as number | undefined);
        break;
      }
    }
  };
  canvas.addEventListener("pointerdown", onDown);
  canvas.addEventListener("pointerup", onUp);

  function syncHotspots() {
    const w = host.clientWidth;
    const h = host.clientHeight;
    const show = new Set<string>();
    const allOut = screws.length > 0 && screws.every((_, i) => bench.screwsIn[i] === false);
    camera.getWorldDirection(forward);
    for (const a of anchors) {
      let visible = false;
      if (a.part === "screw") visible = bench.tool === "driver" && bench.screwsIn[a.index ?? 0] !== false && !bench.open;
      else if (a.part === "cover") visible = bench.tool === "spudger" && allOut && !bench.open;
      else if (a.part === "flex") visible = bench.open && openAmt > 0.45 && (bench.tool === "tweezer" || bench.tool === "hand");
      else if (a.part === "battery" || a.part === "board" || a.part === "soc") visible = bench.open && openAmt > 0.62;
      else if (a.part === "screen") visible = bench.tool === "hand" && !bench.open;
      if (!visible) continue;
      a.obj.getWorldPosition(tmp);
      tmp.sub(camera.position);
      const facing = tmp.dot(forward);
      tmp.add(camera.position);
      if (facing <= 0.05) continue;
      ndc.copy(tmp).project(camera);
      if (ndc.z > 1) continue;
      const x = (ndc.x * 0.5 + 0.5) * w;
      const y = (-ndc.y * 0.5 + 0.5) * h;
      if (x < -20 || y < -20 || x > w + 20 || y > h + 20) continue;
      show.add(a.id);
      let btn = buttons.get(a.id);
      if (!btn) {
        btn = document.createElement("button");
        btn.type = "button";
        btn.addEventListener("pointerdown", (ev) => ev.stopPropagation());
        btn.addEventListener("click", (ev) => {
          ev.stopPropagation();
          const part = btn!.dataset.part || "";
          const idx = btn!.dataset.index;
          hooks.onPick(part, idx == null || idx === "" ? undefined : Number(idx));
        });
        layer.appendChild(btn);
        buttons.set(a.id, btn);
      }
      btn.className = a.big ? "hot" : "hot mini";
      btn.textContent = a.label;
      btn.dataset.part = a.part;
      btn.dataset.index = a.index == null ? "" : String(a.index);
      btn.style.left = `${x}px`;
      btn.style.top = `${y}px`;
    }
    for (const [id, btn] of buttons) {
      if (!show.has(id)) {
        btn.remove();
        buttons.delete(id);
      }
    }
  }

  function screenOn() {
    if (!view) return false;
    if (!bench.batConn) return false;
    if (view.brick || view.c >= 4 || view.d.f) return false;
    return true;
  }

  renderer.setAnimationLoop(() => {
    if (dead) return;
    timer.update();
    const dt = Math.min(timer.getDelta(), 0.1);
    const k = reduce ? 1 : 1 - Math.exp(-10 * dt);
    openAmt += ((bench.open ? 1 : 0) - openAmt) * k;
    flexAmt += (((bench.batConn ? 0 : 1) - flexAmt) * k);
    if (cover && screenG) {
      const slide = opensFront ? screenG : cover;
      const dir = opensFront ? -1 : 1;
      slide.position.x = dir * openAmt * 0.78;
      slide.position.z = openAmt * 0.26 * (opensFront ? -1 : 1);
      slide.rotation.y = dir * openAmt * 0.7;
      slide.rotation.z = dir * openAmt * 0.08;
      if (!opensFront) cover.position.z += (1 - openAmt) * swell;
      if (opensFront) cover.position.z = swell;
      if (opensFront) screenG.position.z += 0;
    }
    screws.forEach((s, i) => {
      const target = bench.screwsIn[i] === false ? 1 : 0;
      screwT[i] += (target - screwT[i]) * k;
      const t = screwT[i];
      s.position.copy(screwHome[i]);
      s.position.z += t * 0.28 * (opensFront ? -1 : 1);
      s.position.y -= t * 0.22;
      s.rotation.z = t * 12;
      s.visible = t < 0.98;
      const head = s.children[0] as THREE.Mesh;
      const hm = head?.material as THREE.MeshStandardMaterial | undefined;
      if (hm?.emissive) {
        const hot = bench.tool === "driver" && bench.screwsIn[i] !== false && !bench.open;
        hm.emissive.setHex(hot ? 0xffd60a : 0x000000);
        hm.emissiveIntensity = hot ? 0.55 : 0;
      }
    });
    if (flexMesh) {
      flexMesh.position.copy(flexHome);
      flexMesh.position.x += flexAmt * 0.05;
      flexMesh.rotation.z = flexAmt * -0.7;
    }
    if (shakeAmt > 0 && phoneRoot) {
      shakeAmt = Math.max(0, shakeAmt - dt * 2.2);
      phoneRoot.rotation.z = Math.sin(timer.getElapsed() * 46) * 0.03 * shakeAmt;
    } else if (phoneRoot) phoneRoot.rotation.z = 0;
    if (idle > 0) {
      idle += dt;
      if (idle > 2.8 && !bench.open && !flying && !reduce) controls.autoRotate = true;
    }
    if (bench.open) controls.autoRotate = false;
    if (flying) {
      camera.position.lerp(fly, 1 - Math.exp(-5 * dt));
      if (camera.position.distanceTo(fly) < 0.02) flying = false;
    }
    const booting = !!(boot && performance.now() < boot.until);
    if (boot && !booting && !bootSent && boot.token === bootToken) {
      bootSent = true;
      hooks.onBootEnd(boot.token);
    }
    if (screenCtx && screenTexture && view && (screenDirty || booting || (view.d.s === 1 && screenOn()))) {
      paintScreen(screenCtx, view, screenOn(), boot);
      screenTexture.needsUpdate = true;
      screenDirty = false;
    }
    syncHotspots();
    controls.update();
    renderer.render(scene, camera);
  });

  void document.fonts?.ready.then(() => {
    screenDirty = true;
  });

  let wasOpen = false;
  return {
    setPhone(v) {
      if (dead) return;
      const prevId = view?.id;
      view = v;
      if (!v) {
        clearPhone();
        return;
      }
      if (v.sig !== builtSig) {
        build(v);
        if (prevId !== v.id) {
          openAmt = bench.open ? 1 : 0;
          camera.position.copy(backPos);
          flying = false;
          controls.target.set(0, 0, 0);
        }
      }
      screenDirty = true;
    },
    setBench(b, nextBoot, shake) {
      if (dead) return;
      const opened = b.open && !wasOpen;
      const closed = !b.open && wasOpen;
      wasOpen = b.open;
      bench = b;
      boot = nextBoot;
      if (nextBoot && nextBoot.token !== bootToken) {
        bootToken = nextBoot.token;
        bootSent = false;
        screenDirty = true;
      }
      if (!nextBoot) {
        bootToken = "";
        bootSent = false;
      }
      if (shake !== lastShake) {
        lastShake = shake;
        shakeAmt = 1;
      }
      if (opened) flyTo(insidePos);
      if (closed) flyTo(opensFront ? frontPos : backPos);
    },
    focus(which) {
      if (which === "front") flyTo(frontPos);
      else if (which === "inside") flyTo(insidePos);
      else flyTo(backPos);
    },
    dispose() {
      dead = true;
      renderer.setAnimationLoop(null);
      timer.disconnect();
      controls.dispose();
      ro.disconnect();
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointerup", onUp);
      clearPhone();
      matMap.dispose();
      desk.geometry.dispose();
      (desk.material as THREE.Material).dispose();
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
      canvas.remove();
      layer.remove();
    },
  };
}
