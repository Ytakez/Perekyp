import {
  BRANDS,
  COND,
  CPU,
  FK,
  GOAL,
  MODELS,
  NAMES_F,
  NAMES_L,
  NAMES_W,
  PROBS,
  ROMS,
  baseTier,
  clamp,
  fmt,
  pname,
  r100,
  rnd,
} from "./catalog";
import { layoutFor } from "./layout";
import type { Bench, Boot, Damage, Job, Phone, PhoneView, Rom, State, Tab, Tool } from "./types";

export function emptyBench(): Bench {
  return { mode: "own", phoneId: null, tool: "hand", screwsIn: [true, true, true, true], open: false, batConn: true };
}

function mkD(c: number): Damage {
  const h = Math.random() < 0.5;
  return {
    b: c === 1 || c === 4 ? (h ? 1 : 0) : 0,
    s: c === 2 ? (h ? 1 : 0) : c === 3 ? 2 : 0,
    f: c === 4 ? (h ? 0 : 1) : 0,
    w: 0,
  };
}

export function allRoms(s: State): Rom[] {
  return ROMS.concat(s.customRoms);
}

export function romOf(s: State, id: string): Rom {
  return allRoms(s).find((r) => r.id === id) ?? ROMS[0];
}

export function hw(s: State, p: Phone) {
  const rom = romOf(s, p.rom);
  const bt = baseTier(p.base);
  const t = p.cpu == null ? bt : clamp(p.cpu, 0, 4);
  return { rom, romMult: p.brick ? 0.4 : rom.p, t, bt };
}

export function phoneValue(s: State, p: Phone, fakePenalty: boolean) {
  const h = hw(s, p);
  const cm = CPU[h.t].mult / CPU[h.bt].mult;
  const fake = fakePenalty && p.fake ? 0.2 : 1;
  return p.base * COND[p.c].m * (s.idx[p.brand] ?? 1) * fake * h.romMult * cm;
}

export function worth(s: State) {
  return s.cash + s.inv.reduce((a, p) => a + (p.job ? 0 : phoneValue(s, p, true)), 0);
}

export function fullCost(p: Phone) {
  return p.c === 4 ? Math.max(2000, r100(p.base * 0.28)) : Math.max(1500, r100(p.base * 0.13));
}
export function batCost(p: Phone) {
  return Math.max(800, r100(p.base * 0.06));
}
export function screenCost(p: Phone) {
  return Math.max(1500, r100(p.base * 0.12));
}
export function boardCost(p: Phone) {
  return Math.max(2000, r100(p.base * 0.22));
}
export function cpuCost(next: number) {
  return r100(3500 * (next + 1));
}

export function romFits(rom: Rom, brand: string) {
  if (!rom.b) return true;
  if (rom.b === "Xiaomi") return brand === "Xiaomi" || brand === "Redmi" || brand === "Poco";
  if (rom.b === "OnePlus") return brand === "OnePlus" || brand === "OPPO" || brand === "Realme";
  return rom.b === brand;
}

export function romRisk(rom: Rom, brand: string) {
  return Math.min(0.85, romFits(rom, brand) ? rom.r : rom.r * 2.4 + 0.12);
}

export function jobBlocked(p: Phone): string | null {
  if (p.brick) return "Кирпич после прошивки.";
  if (p.c > 1) return "Клиент ждёт состояние не хуже «хорошего».";
  if (p.d.f) return "Телефон всё ещё не включается.";
  if (p.d.s === 2) return "Экран всё ещё разбит.";
  return null;
}

function said(s: State, t: string): State {
  s.msg = t;
  s.log = [`День ${s.day}: ${t}`, ...s.log].slice(0, 50);
  return s;
}

function makePhone(s: State): Phone {
  const b = rnd(BRANDS);
  const m = rnd(MODELS[b]);
  const roll = Math.random();
  const c = roll < 0.3 ? 0 : roll < 0.6 ? 1 : roll < 0.8 ? 2 : roll < 0.92 ? 3 : 4;
  const id = s.nextId++;
  const p: Phone = {
    id,
    brand: b,
    model: m[0],
    base: m[1],
    c,
    fake: false,
    fk: rnd(FK),
    seen: false,
    listed: 0,
    haggled: false,
    paid: 0,
    d: mkD(c),
    rom: "stock",
    cpu: null,
    color: id % 5,
    ask: 0,
    floor: 0,
    sellerR: Math.round((3.2 + Math.random() * 1.8) * 10) / 10,
    sellerN: 2 + Math.floor(Math.random() * 80),
    job: false,
    jobId: 0,
    seal: 0,
    brick: false,
  };
  const v = p.base * COND[c].m * (s.idx[b] ?? 1);
  const disc = 0.6 + Math.random() * 0.5;
  p.ask = r100(v * disc);
  p.floor = p.ask * (0.8 + Math.random() * 0.15);
  p.fake = p.base >= 15000 && Math.random() < (disc < 0.78 ? 0.22 : 0.05);
  if (c === 4 && p.d.f && Math.random() < 0.45) p.d.w = 1;
  return p;
}

function makeCust() {
  const w = Math.random() < 0.45;
  const fn = rnd(w ? NAMES_W : NAMES_F);
  const ln = rnd(NAMES_L);
  return { name: fn + " " + ln, phone: "+7 9" + String(100000000 + Math.floor(Math.random() * 899999999)) };
}

function makeJob(s: State): Job {
  const b = rnd(BRANDS);
  const m = rnd(MODELS[b]);
  const pr = rnd(PROBS);
  const id = s.nextId++;
  const c = pr.c;
  const p: Phone = {
    id,
    brand: b,
    model: m[0],
    base: m[1],
    c,
    fake: false,
    fk: "",
    seen: true,
    listed: 0,
    haggled: false,
    paid: 0,
    d: mkD(c),
    rom: "stock",
    cpu: null,
    color: id % 5,
    ask: 0,
    floor: 0,
    sellerR: 5,
    sellerN: 0,
    job: true,
    jobId: 0,
    seal: 0,
    brick: false,
  };
  if (pr.id === "bat") p.d.b = 1;
  if (pr.id === "boot") p.d.f = 1;
  if (pr.id === "lines") p.d.s = 1;
  if (pr.id === "screen") p.d.s = 2;
  if (pr.id === "dead" || pr.id === "water") {
    p.d.f = 1;
    p.c = 4;
  }
  if (pr.id === "water") p.d.w = 1;
  if (pr.id === "charge") p.d.f = 1;
  const pay = r100(p.base * pr.pay * (0.85 + Math.random() * 0.35));
  const jid = s.nextJid++;
  p.jobId = jid;
  return { id: jid, cust: makeCust(), prob: pr, phone: p, pay, status: "wait", dayIn: s.day };
}

export function fresh(): State {
  const s: State = {
    v: 1,
    day: 1,
    cash: 30000,
    slots: 4,
    inv: [],
    mk: [],
    idx: {},
    log: ["День 1: В кармане 30 000 ₽. Открой телефон в 3D и сними крышку — внутри батарея и плата."],
    nextId: 1,
    nextJid: 1,
    tab: "mk",
    msg: "Нажми «В 3D» на карточке — модель крутится, крышка снимается.",
    won: 0,
    sold: 0,
    jobs: [],
    doneJobs: 0,
    svcEarn: 0,
    rating: 4.2,
    reviews: 3,
    repairsDone: 0,
    customRoms: [],
    romSeq: 1,
    bench: emptyBench(),
    boot: null,
    shake: 0,
  };
  for (const b of BRANDS) s.idx[b] = 1;
  while (s.mk.length < 8) s.mk.push(makePhone(s));
  while (s.jobs.length < 3) s.jobs.push(makeJob(s));
  return s;
}

function clone(s: State): State {
  return structuredClone(s);
}

function win(s: State): State {
  if (!s.won && worth(s) >= GOAL) {
    s.won = 1;
    return said(s, `Цель взята: имущество ${fmt(worth(s))}. Лавку можно не закрывать.`);
  }
  return s;
}

function own(s: State, id: number) {
  return s.inv.find((p) => p.id === id) ?? null;
}

export function benchPhone(s: State): { phone: Phone; own: boolean } | null {
  if (s.bench.phoneId == null) return null;
  if (s.bench.mode === "own") {
    const p = s.inv.find((x) => x.id === s.bench.phoneId);
    return p ? { phone: p, own: true } : null;
  }
  const p = s.mk.find((x) => x.id === s.bench.phoneId);
  return p ? { phone: p, own: false } : null;
}

export function toView(s: State): PhoneView | null {
  const ctx = benchPhone(s);
  if (!ctx) return null;
  const p = ctx.phone;
  const h = hw(s, p);
  const sig = [p.id, p.brand, p.model, p.base, p.c, p.color, p.d.b, p.d.s, p.d.f, p.d.w, p.rom, p.brick ? 1 : 0, p.fake && p.seen ? 1 : 0, h.t].join("|");
  return {
    id: p.id,
    sig,
    brand: p.brand,
    model: p.model,
    base: p.base,
    c: p.c,
    color: p.color,
    d: p.d,
    theme: h.rom.th,
    romName: h.rom.n,
    fakeSeen: p.fake && p.seen,
    brick: p.brick,
    cpuLabel: CPU[h.t].n,
  };
}

function dropBench(s: State, id: number) {
  if (s.bench.phoneId === id) s.bench = emptyBench();
}

export function doBuy(prev: State, id: number): State {
  const s = clone(prev);
  const l = s.mk.find((p) => p.id === id);
  if (!l) return prev;
  if (s.cash < l.ask) return said(s, "Не хватает денег.");
  if (s.inv.length >= s.slots) return said(s, "Склад забит. Продай или расширь.");
  s.cash -= l.ask;
  l.paid = l.ask;
  s.mk = s.mk.filter((p) => p.id !== id);
  s.inv.push(l);
  s.mk.push(makePhone(s));
  if (s.bench.phoneId === id) {
    s.bench = { ...s.bench, mode: "own" };
  }
  return said(s, `Куплен ${pname(l)} за ${fmt(l.paid)}.`);
}

export function doCheck(prev: State, id: number): State {
  const s = clone(prev);
  const l = s.mk.find((p) => p.id === id);
  if (!l) return prev;
  if (l.seen) return said(s, "Этот уже проверен.");
  if (s.cash < 250) return said(s, "Проверка IMEI стоит 250 ₽.");
  s.cash -= 250;
  l.seen = true;
  return said(s, l.fake ? `IMEI: ${pname(l)} — ${l.fk}. Лучше не брать.` : `IMEI: ${pname(l)} чистый.`);
}

export function doHaggle(prev: State, id: number): State {
  const s = clone(prev);
  const l = s.mk.find((p) => p.id === id);
  if (!l) return prev;
  if (l.haggled) return said(s, "С этим продавцом уже торговался.");
  l.haggled = true;
  const o = r100(l.ask * 0.88);
  if (o >= l.floor) {
    l.ask = o;
    return said(s, `Продавец уступил: теперь ${fmt(o)}.`);
  }
  if (Math.random() < 0.4) {
    s.mk = s.mk.filter((p) => p.id !== id);
    s.mk.push(makePhone(s));
    if (s.bench.phoneId === id) s.bench = emptyBench();
    return said(s, "Продавец обиделся и ушёл.");
  }
  return said(s, "Продавец не уступает.");
}

export function doShop(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  if (p.job) return said(s, "Это заказ клиента. Выдай через сервис или верни.");
  const v = r100(phoneValue(s, p, true) * 0.7);
  s.cash += v;
  s.sold++;
  s.inv = s.inv.filter((x) => x.id !== id);
  dropBench(s, id);
  return win(said(s, `Скупка взяла ${pname(p)} за ${fmt(v)}${p.fake ? " — оказалось, " + p.fk.toLowerCase() + "." : ` (куплен за ${fmt(p.paid)}).`}`));
}

export function doList(prev: State, id: number, price: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  if (p.job) return said(s, "Телефон клиента нельзя на OLX.");
  if (!price || price < 1) return said(s, "Напиши цену.");
  p.listed = r100(price);
  return said(s, `${pname(p)} на OLX за ${fmt(p.listed)}. Рейтинг ${s.rating.toFixed(1)} влияет на скорость.`);
}

export function doUnlist(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  p.listed = 0;
  s.msg = "Снял с OLX.";
  return s;
}

function pay(s: State, cost: number) {
  if (s.cash < cost) return false;
  s.cash -= cost;
  return true;
}

export function doFullFix(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  if (p.c <= 1 && !p.d.b && !p.d.s && !p.d.f && !p.brick) return said(s, "Чинить нечего.");
  const c = fullCost(p);
  if (!pay(s, c)) return said(s, `Полный ремонт стоит ${fmt(c)}.`);
  p.paid += c;
  p.d = { b: 0, s: 0, f: 0, w: 0 };
  p.brick = false;
  if (p.c > 1) p.c = 1;
  p.listed = 0;
  s.repairsDone++;
  return said(s, `${pname(p)} приведён в порядок за ${fmt(c)}.`);
}

export function doBat(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  if (!s.bench.open || s.bench.phoneId !== id) return said(s, "Сначала вскрой этот телефон в цехе.");
  if (s.bench.batConn) return said(s, "Пинцетом отключи шлейф батареи.");
  if (!p.d.b) return said(s, "Батарея и так ровная.");
  const c = batCost(p);
  if (!pay(s, c)) return said(s, `Новая АКБ стоит ${fmt(c)}.`);
  p.paid += c;
  p.d.b = 0;
  s.repairsDone++;
  return said(s, `Поставил новую батарею в ${pname(p)} за ${fmt(c)}.`);
}

export function doScreen(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  if (!s.bench.open || s.bench.phoneId !== id) return said(s, "Сначала сними крышку или экран в цехе.");
  if (!p.d.s && p.c !== 3) return said(s, "Экран целый.");
  const c = screenCost(p);
  if (!pay(s, c)) return said(s, `Дисплей стоит ${fmt(c)}.`);
  p.paid += c;
  p.d.s = 0;
  if (p.c >= 2) p.c = 1;
  p.listed = 0;
  s.repairsDone++;
  return said(s, `Заменил экран ${pname(p)} за ${fmt(c)}.`);
}

export function doBoard(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  if (!s.bench.open || s.bench.phoneId !== id) return said(s, "Плату не достать, пока крышка на месте.");
  if (s.bench.batConn) return said(s, "Сначала сними шлейф батареи.");
  if (!p.d.f && !p.brick && !p.d.w && p.c !== 4) return said(s, "Плата живая.");
  const c = boardCost(p);
  if (!pay(s, c)) return said(s, `Ремонт платы стоит ${fmt(c)}.`);
  p.paid += c;
  p.d.f = 0;
  p.d.w = 0;
  p.brick = false;
  if (p.c > 1) p.c = 1;
  p.listed = 0;
  s.repairsDone++;
  return said(s, `Пропаял плату ${pname(p)} за ${fmt(c)}.`);
}

export function doSeal(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p || p.job) return p?.job ? said(s, "На клиентский телефон пломбу не клеим.") : prev;
  if (p.seal) return said(s, "Пломба уже стоит.");
  if (p.c > 1 || p.d.s === 2 || p.d.f || p.brick) return said(s, "Сначала почини телефон.");
  if (s.cash < 500) return said(s, "Пломба и гарантия — 500 ₽.");
  s.cash -= 500;
  p.paid += 500;
  p.seal = 1;
  return said(s, `${pname(p)}: гарантийная пломба. На OLX берут охотнее.`);
}

export function doSlot(prev: State): State {
  const s = clone(prev);
  if (s.slots >= 12) return said(s, "Склад и так огромный.");
  const c = (s.slots - 3) * 6000;
  if (s.cash < c) return said(s, `Ещё одно место стоит ${fmt(c)}.`);
  s.cash -= c;
  s.slots++;
  return said(s, `Склад расширен до ${s.slots} мест.`);
}

export function doJobOk(prev: State, id: number): State {
  const s = clone(prev);
  const j = s.jobs.find((x) => x.id === id);
  if (!j || j.status !== "wait") return prev;
  if (s.inv.length >= s.slots) return said(s, "Нет места на складе.");
  j.status = "work";
  j.dayIn = s.day;
  j.phone.job = true;
  j.phone.paid = 0;
  s.inv.push(j.phone);
  return said(s, `Принят заказ: ${pname(j.phone)} от ${j.cust.name}. После ремонта ${fmt(j.pay)}.`);
}

export function doJobNo(prev: State, id: number): State {
  const s = clone(prev);
  s.jobs = s.jobs.filter((x) => x.id !== id);
  s.msg = "Заявка отклонена.";
  return s;
}

export function doJobDone(prev: State, id: number): State {
  const s = clone(prev);
  const j = s.jobs.find((x) => x.id === id);
  if (!j) return prev;
  const p = s.inv.find((x) => x.id === j.phone.id);
  if (!p) return said(s, "Телефон не на складе.");
  if (j.prob.id === "bat" && p.d.b) return said(s, "Клиент не примет: батарея всё ещё слабая.");
  if ((j.prob.id === "lines" || j.prob.id === "screen") && p.d.s) return said(s, "Клиент не примет: экран не готов.");
  const why = jobBlocked(p);
  if (why) return said(s, "Клиент не примет: " + why);
  s.cash += j.pay;
  s.svcEarn += j.pay;
  s.doneJobs++;
  s.repairsDone++;
  s.rating = clamp(Math.round((s.rating + 0.12) * 10) / 10, 1, 5);
  s.reviews++;
  s.inv = s.inv.filter((x) => x.id !== p.id);
  s.jobs = s.jobs.filter((x) => x.id !== j.id);
  dropBench(s, p.id);
  return win(said(s, `Выдан ${pname(p)} → ${j.cust.name}. +${fmt(j.pay)}.`));
}

export function doJobFail(prev: State, id: number): State {
  const s = clone(prev);
  const j = s.jobs.find((x) => x.id === id);
  if (!j) return prev;
  s.inv = s.inv.filter((x) => x.id !== j.phone.id);
  s.jobs = s.jobs.filter((x) => x.id !== j.id);
  s.rating = clamp(Math.round((s.rating - 0.2) * 10) / 10, 1, 5);
  s.reviews++;
  dropBench(s, j.phone.id);
  return said(s, `Вернули ${pname(j.phone)} клиенту ${j.cust.name} без оплаты. Рейтинг просел.`);
}

function rateSale(s: State, d: number) {
  s.rating = clamp(Math.round((s.rating + d) * 10) / 10, 1, 5);
  s.reviews++;
}

export function doDay(prev: State): State {
  const s = clone(prev);
  s.boot = null;
  s.day++;
  let bestB = "";
  let bestD = 0;
  for (const b of BRANDS) {
    const next = clamp(s.idx[b] * (0.96 + Math.random() * 0.09), 0.72, 1.35);
    const delta = next - s.idx[b];
    s.idx[b] = Math.round(next * 100) / 100;
    if (Math.abs(delta) > Math.abs(bestD)) {
      bestD = delta;
      bestB = b;
    }
  }
  const notes: string[] = [];
  if (bestB) notes.push(`Рынок: ${bestB} ${bestD >= 0 ? "+" : ""}${Math.round(bestD * 100)}%.`);
  const keep: Phone[] = [];
  for (const p of s.inv) {
    if (!p.listed || p.job) {
      keep.push(p);
      continue;
    }
    const perceived = phoneValue(s, p, false);
    const ratio = p.listed / Math.max(1, perceived);
    let chance = ratio < 0.85 ? 0.62 : ratio < 1 ? 0.4 : ratio < 1.15 ? 0.22 : ratio < 1.4 ? 0.1 : 0.04;
    chance *= 0.75 + (s.rating / 5) * 0.5;
    if (p.seal) chance *= 1.2;
    if (p.c >= 3) chance *= 0.75;
    if (p.d.b) chance *= 0.85;
    if (p.fake) chance *= 0.55;
    if (Math.random() < chance) {
      if (p.fake && Math.random() < 0.55) {
        const pay = r100(p.listed * 0.4);
        s.cash += pay;
        rateSale(s, -0.3);
        notes.push(`OLX спор: ${pname(p)} — ${p.fk}. На руки ${fmt(pay)}.`);
      } else {
        s.cash += p.listed;
        s.sold++;
        rateSale(s, 0.05);
        notes.push(`OLX: продан ${pname(p)} за ${fmt(p.listed)}.`);
      }
      dropBench(s, p.id);
    } else keep.push(p);
  }
  s.inv = keep;
  for (let i = 0; i < 3; i++) {
    const idx = Math.floor(Math.random() * s.mk.length);
    const gone = s.mk[idx];
    if (gone && s.bench.mode === "look" && s.bench.phoneId === gone.id) s.bench = emptyBench();
    s.mk.splice(idx, 1);
    s.mk.push(makePhone(s));
  }
  s.jobs = s.jobs.filter((j) => j.status === "work" || s.day - j.dayIn < 4);
  const waiting = s.jobs.filter((j) => j.status === "wait").length;
  if (waiting < 3) s.jobs.push(makeJob(s));
  const line = notes.join(" ") || "Тихий день: никто не купил.";
  return win(said(s, line));
}

export function doTab(prev: State, tab: Tab): State {
  const s = clone(prev);
  s.tab = tab;
  return s;
}

export function doLook(prev: State, id: number): State {
  const s = clone(prev);
  const p = s.mk.find((x) => x.id === id);
  if (!p) return prev;
  const L = layoutFor(p.brand, p.model, p.base);
  const same = s.bench.phoneId === id && s.bench.mode === "look";
  s.tab = "shop";
  if (!same) {
    s.bench = { mode: "look", phoneId: id, tool: "hand", screwsIn: Array(L.screws).fill(true), open: false, batConn: true };
    s.boot = null;
  }
  return said(s, `${pname(p)} на столе. Отвёртка снимает винты, лопатка — крышку. Внутри батарея и плата.`);
}

export function doWorkshop(prev: State, id: number): State {
  const s = clone(prev);
  const p = own(s, id);
  if (!p) return prev;
  const L = layoutFor(p.brand, p.model, p.base);
  const same = s.bench.phoneId === id && s.bench.mode === "own";
  s.tab = "shop";
  if (!same) {
    s.bench = { mode: "own", phoneId: id, tool: "hand", screwsIn: Array(L.screws).fill(true), open: false, batConn: true };
    s.boot = null;
  }
  return said(s, `${pname(p)} в цехе. Сними крышку — увидишь аккумулятор, плату и шлейфы.`);
}

export function doTool(prev: State, tool: Tool): State {
  const s = clone(prev);
  s.bench = { ...s.bench, tool };
  return s;
}

export function doPick(prev: State, part: string, index?: number): State {
  const s = clone(prev);
  const ctx = benchPhone(s);
  if (!ctx) return prev;
  const tool = s.bench.tool;
  const L = layoutFor(ctx.phone.brand, ctx.phone.model, ctx.phone.base);
  if (part === "screw") {
    if (tool !== "driver") return said(s, "Возьми отвёртку — винты подсвечены.");
    const i = index ?? 0;
    if (!s.bench.screwsIn[i]) return said(s, "Этот винт уже лежит на коврике.");
    const screwsIn = s.bench.screwsIn.slice();
    screwsIn[i] = false;
    s.bench = { ...s.bench, screwsIn };
    const left = screwsIn.filter(Boolean).length;
    return said(s, left ? `Винт выкручен. Осталось ${left}.` : L.opensFront ? "Винты сняты. Лопаткой поддень экран." : "Винты сняты. Лопаткой сними крышку.");
  }
  if (part === "cover") {
    const allOut = s.bench.screwsIn.every((v) => !v);
    if (!allOut) {
      s.shake++;
      return said(s, "Держится на винтах. Сначала отвёртка.");
    }
    if (tool !== "spudger") return said(s, "Возьми лопатку и поддень.");
    const open = !s.bench.open;
    s.bench = { ...s.bench, open };
    if (!open) return said(s, "Закрыл обратно.");
    const guts = ctx.phone.d.b
      ? "Батарея вздута и давит на крышку."
      : ctx.phone.d.w
        ? "На плате белый налёт — вода."
        : "Внутри аккумулятор, плата, камеры и шлейф.";
    return said(s, (L.opensFront ? "Экран снят. " : "Крышка снята. ") + guts);
  }
  if (part === "flex") {
    if (!s.bench.open) return said(s, "Шлейф под крышкой.");
    if (tool !== "tweezer") return said(s, "Возьми пинцет.");
    const batConn = !s.bench.batConn;
    s.bench = { ...s.bench, batConn };
    return said(s, batConn ? "Шлейф батареи сел в разъём." : "Шлейф отключён. Теперь можно менять АКБ и плату.");
  }
  if (part === "battery") {
    s.msg = ctx.phone.d.b ? "Аккумулятор вздут, оболочка тугая. Меняй, пока не потёк." : "Аккумулятор ровный, контакты золотые, без окисла.";
    return s;
  }
  if (part === "board" || part === "soc") {
    const cpu = CPU[hw(s, ctx.phone).t].n;
    s.msg = ctx.phone.d.w
      ? `Плата с окислами. Процессор: ${cpu}.`
      : ctx.phone.brick || ctx.phone.d.f
        ? `Плата молчит, питание не стартует. Процессор: ${cpu}.`
        : `Плата сухая. Процессор: ${cpu}.`;
    return s;
  }
  if (part === "screen") {
    s.msg = ctx.phone.d.s === 2 || ctx.phone.c === 3 ? "Стекло в паутине, матрица течёт." : ctx.phone.d.s === 1 ? "По матрице идут полосы." : "Экран целый.";
    return s;
  }
  return s;
}

export function doFlash(prev: State, romId: string): State {
  const s = clone(prev);
  const ctx = benchPhone(s);
  if (!ctx?.own) return said(s, ctx ? "Чужой телефон не шьём." : "Сначала положи свой телефон на стол.");
  if (s.boot) return said(s, "Прошивка ещё льётся.");
  if (!s.bench.batConn) return said(s, "Подключи шлейф — без батареи кабель не видит телефон.");
  const rom = romOf(s, romId);
  if (ctx.phone.rom === rom.id && !ctx.phone.brick) return said(s, "Эта прошивка уже стоит.");
  if (rom.c && s.cash < rom.c) return said(s, `${rom.n} стоит ${fmt(rom.c)}.`);
  if (rom.c) s.cash -= rom.c;
  const risk = romRisk(rom, ctx.phone.brand);
  const fail = Math.random() < risk;
  const p = own(s, ctx.phone.id);
  if (!p) return prev;
  if (fail) {
    p.brick = true;
    p.c = 4;
    p.d.f = 1;
    p.listed = 0;
  } else {
    p.rom = rom.id;
    if (p.brick || p.d.f) {
      p.brick = false;
      p.d.f = 0;
      if (p.c === 4) p.c = 1;
    }
  }
  const token = Math.random().toString(36).slice(2, 8);
  s.boot = { name: rom.n, until: performance.now() + 2200, token, ok: !fail } satisfies Boot;
  const warn = romFits(rom, p.brand) ? "" : " Чужой вендор — риск выше.";
  return said(s, fail ? `${pname(p)} стал кирпичом на ${rom.n}.${warn}` : `Прошил ${pname(p)} → ${rom.n}. К цене ×${rom.p.toFixed(2)}.${warn}`);
}

export function clearBoot(prev: State, token: string): State {
  if (!prev.boot || prev.boot.token !== token) return prev;
  return { ...prev, boot: null };
}

export function doCpu(prev: State): State {
  const s = clone(prev);
  const ctx = benchPhone(s);
  if (!ctx?.own) return said(s, "Перепаивать можно только свой телефон.");
  if (!s.bench.open || s.bench.phoneId !== ctx.phone.id) return said(s, "Вскрой корпус — чип под экраном платы.");
  if (s.bench.batConn) return said(s, "Сними шлейф батареи перед пайкой.");
  const p = own(s, ctx.phone.id)!;
  const cur = hw(s, p).t;
  if (cur >= 4) return said(s, "Стоит уже топовый чип.");
  const next = cur + 1;
  const c = cpuCost(next);
  if (s.cash < c) return said(s, `${CPU[next].n} обойдётся в ${fmt(c)}.`);
  s.cash -= c;
  p.paid += c;
  if (Math.random() < 0.12) {
    p.brick = true;
    p.c = 4;
    p.d.f = 1;
    p.listed = 0;
    return said(s, `Перегрел плату. ${pname(p)} не включается.`);
  }
  p.cpu = next;
  return said(s, `На ${pname(p)} теперь ${CPU[next].n}. Оценка выросла.`);
}

export function doCustom(prev: State, aggressive: boolean): State {
  const s = clone(prev);
  const n = s.romSeq++;
  const rom: Rom = aggressive
    ? { id: "c" + n, n: "Сборка «Злая» " + n, b: null, r: 0.22, p: 1.26, c: 1000, d: "Разгон и вырезанный мусор", th: ["#f43f5e", "#9f1239", "#1a0a10", "#fda4af"] }
    : { id: "c" + n, n: "Сборка «Тихая» " + n, b: null, r: 0.07, p: 1.12, c: 0, d: "Своя бережная прошивка", th: ["#0f766e", "#134e4a", "#042f2e", "#99f6e4"] };
  s.customRoms.push(rom);
  return said(s, `Собрал прошивку «${rom.n}». Она в списке внизу.`);
}

export function doReset(): State {
  return fresh();
}

export { GOAL, fmt, pname, COND, CPU };
