import { create } from "zustand";
import { sfx } from "./sfx";
import {
  clearBoot as clearBootState,
  doBat,
  doBoard,
  doBuy,
  doCheck,
  doCpu,
  doCustom,
  doDay,
  doFlash,
  doFullFix,
  doHaggle,
  doJobDone,
  doJobFail,
  doJobNo,
  doJobOk,
  doList,
  doLook,
  doPick,
  doReset,
  doScreen,
  doSeal,
  doShop,
  doSlot,
  doTab,
  doTool,
  doUnlist,
  doWorkshop,
  emptyBench,
  fresh,
} from "./logic";
import type { State, Tab, Tool } from "./types";

const KEY = "perekup-v1";

export const useGame = create<State>(() => fresh());

let hydrated = false;

function commit(next: State) {
  if (hydrated) {
    localStorage.setItem(KEY, JSON.stringify({ ...next, boot: null, shake: 0 }));
  }
  useGame.setState(next, true);
}

export function hydrate() {
  if (hydrated) return;
  hydrated = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as State;
      if (p && p.v === 1 && Array.isArray(p.mk) && Array.isArray(p.inv)) {
        p.boot = null;
        p.shake = 0;
        if (!p.bench) p.bench = emptyBench();
        if (!p.customRoms) p.customRoms = [];
        if (!p.idx) p.idx = {};
        useGame.setState(p, true);
        return;
      }
    }
  } catch {
    /* keep fresh */
  }
  commit(useGame.getState());
}

function cash(fn: (s: State) => State, spend: "out" | "in" | "none" = "none") {
  const before = useGame.getState().cash;
  const next = fn(useGame.getState());
  commit(next);
  if (spend === "out" && next.cash < before) sfx("cash");
  if (spend === "in" && next.cash > before) sfx("cash");
}

export const buy = (id: number) => cash((s) => doBuy(s, id), "out");
export const checkImei = (id: number) => cash((s) => doCheck(s, id), "out");
export const haggle = (id: number) => commit(doHaggle(useGame.getState(), id));
export const sellShop = (id: number) => cash((s) => doShop(s, id), "in");
export const listPhone = (id: number, price: number) => commit(doList(useGame.getState(), id, price));
export const unlist = (id: number) => commit(doUnlist(useGame.getState(), id));
export const fullFix = (id: number) => cash((s) => doFullFix(s, id), "out");
export const fixBat = (id: number) => cash((s) => doBat(s, id), "out");
export const fixScreen = (id: number) => cash((s) => doScreen(s, id), "out");
export const fixBoard = (id: number) => cash((s) => doBoard(s, id), "out");
export const seal = (id: number) => cash((s) => doSeal(s, id), "out");
export const addSlot = () => cash((s) => doSlot(s), "out");
export const takeJob = (id: number) => commit(doJobOk(useGame.getState(), id));
export const dropJob = (id: number) => commit(doJobNo(useGame.getState(), id));
export const finishJob = (id: number) => cash((s) => doJobDone(s, id), "in");
export const failJob = (id: number) => commit(doJobFail(useGame.getState(), id));
export const newDay = () => commit(doDay(useGame.getState()));
export const setTab = (tab: Tab) => commit(doTab(useGame.getState(), tab));
export const lookPhone = (id: number) => commit(doLook(useGame.getState(), id));
export const workshop = (id: number) => commit(doWorkshop(useGame.getState(), id));
export const setTool = (tool: Tool) => commit(doTool(useGame.getState(), tool));
export const flashRom = (id: string) => cash((s) => doFlash(s, id), "out");
export const upgradeCpu = () => cash((s) => doCpu(s), "out");
export const makeRom = (aggressive: boolean) => commit(doCustom(useGame.getState(), aggressive));
export const resetGame = () => commit(doReset());

export function pick(part: string, index?: number) {
  const prev = useGame.getState();
  const next = doPick(prev, part, index);
  if (next === prev) return;
  commit(next);
  if (next.shake !== prev.shake) sfx("err");
  else if (part === "screw") sfx("screw");
  else if (next.bench.open !== prev.bench.open) sfx("open");
  else if (next.bench.batConn !== prev.bench.batConn) sfx("click");
  else sfx("click");
}

export function endBoot(token: string) {
  const prev = useGame.getState();
  const next = clearBootState(prev, token);
  if (next !== prev) useGame.setState(next, true);
}
