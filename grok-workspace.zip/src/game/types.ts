export type Tool = "hand" | "driver" | "spudger" | "tweezer";

export type Tab = "mk" | "inv" | "olx" | "svc" | "shop";

export type Damage = { b: number; s: number; f: number; w: number };

export type Phone = {
  id: number;
  brand: string;
  model: string;
  base: number;
  c: number;
  fake: boolean;
  fk: string;
  seen: boolean;
  listed: number;
  haggled: boolean;
  paid: number;
  d: Damage;
  rom: string;
  cpu: number | null;
  color: number;
  ask: number;
  floor: number;
  sellerR: number;
  sellerN: number;
  job: boolean;
  jobId: number;
  seal: number;
  brick: boolean;
};

export type Rom = {
  id: string;
  n: string;
  b: string | null;
  r: number;
  p: number;
  c: number;
  d: string;
  th: [string, string, string, string];
};

export type Problem = { id: string; n: string; c: number; fix: number; pay: number };

export type Job = {
  id: number;
  cust: { name: string; phone: string };
  prob: Problem;
  phone: Phone;
  pay: number;
  status: "wait" | "work";
  dayIn: number;
};

export type Bench = {
  mode: "own" | "look";
  phoneId: number | null;
  tool: Tool;
  screwsIn: boolean[];
  open: boolean;
  batConn: boolean;
};

export type Boot = { name: string; until: number; token: string; ok: boolean } | null;

export type PhoneView = {
  id: number;
  sig: string;
  brand: string;
  model: string;
  base: number;
  c: number;
  color: number;
  d: Damage;
  theme: [string, string, string, string];
  romName: string;
  fakeSeen: boolean;
  brick: boolean;
  cpuLabel: string;
};

export type State = {
  v: 1;
  day: number;
  cash: number;
  slots: number;
  inv: Phone[];
  mk: Phone[];
  idx: Record<string, number>;
  log: string[];
  nextId: number;
  nextJid: number;
  tab: Tab;
  msg: string;
  won: number;
  sold: number;
  jobs: Job[];
  doneJobs: number;
  svcEarn: number;
  rating: number;
  reviews: number;
  repairsDone: number;
  customRoms: Rom[];
  romSeq: number;
  bench: Bench;
  boot: Boot;
  shake: number;
};
