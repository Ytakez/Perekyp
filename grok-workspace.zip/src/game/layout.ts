export type Lens = { x: number; y: number; r: number };

export type Cam = {
  shape: "single" | "dual" | "triple" | "pill" | "bar" | "circle" | "island";
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
  lenses: Lens[];
  flash?: { x: number; y: number };
};

export type PhoneLayout = {
  w: number;
  h: number;
  d: number;
  radius: number;
  wall: number;
  screws: 2 | 4;
  opensFront: boolean;
  board: "L" | "rect";
  port: "lightning" | "usbc";
  front: "island" | "notch" | "punch" | "home";
  cam: Cam;
  hinge: boolean;
  glyph: boolean;
  rog: boolean;
  poco: boolean;
};

export type Finish = { name: string; frame: number; glass: number; accent: number };

const IP: Finish[] = [
  { name: "Чёрный", frame: 0x3a3a3c, glass: 0x16171a, accent: 0x2a2a2c },
  { name: "Белый", frame: 0xe4e4e8, glass: 0xf3f3f5, accent: 0xc8c8ce },
  { name: "Синий", frame: 0x314158, glass: 0x3c5270, accent: 0x243246 },
  { name: "Титан", frame: 0xb5a89c, glass: 0xc8bfb3, accent: 0x8d847a },
  { name: "Зелёный", frame: 0x2c3e34, glass: 0x3a5144, accent: 0x22352a },
];
const SAM: Finish[] = [
  { name: "Графит", frame: 0x2c2e33, glass: 0x1a1c20, accent: 0x3a3d44 },
  { name: "Крем", frame: 0xd9d3c8, glass: 0xe7e1d6, accent: 0xb7b0a4 },
  { name: "Фиолет", frame: 0x3a3148, glass: 0x4c4060, accent: 0x2a2436 },
  { name: "Мята", frame: 0x2f3d38, glass: 0x3d524a, accent: 0x24312c },
  { name: "Серебро", frame: 0xc5c8ce, glass: 0xd5d8de, accent: 0x9aa0a8 },
];
const PX: Finish[] = [
  { name: "Обсидиан", frame: 0x2a2c30, glass: 0x17181b, accent: 0x3a3c40 },
  { name: "Фарфор", frame: 0xe7e4de, glass: 0xf6f3ee, accent: 0xc9c4bb },
  { name: "Орех", frame: 0x6a5a48, glass: 0x7d6b56, accent: 0x4e4336 },
  { name: "Роза", frame: 0x8a6d72, glass: 0xa48488, accent: 0x6d555a },
];
const MI: Finish[] = [
  { name: "Чёрный", frame: 0x2a2a2c, glass: 0x141416, accent: 0x3a3a3c },
  { name: "Белый", frame: 0xe8e8ea, glass: 0xf7f7f8, accent: 0xcfcfd2 },
  { name: "Зелёный", frame: 0x1e3a32, glass: 0x245246, accent: 0x163028 },
  { name: "Титан", frame: 0x8d9096, glass: 0xb0b4ba, accent: 0x6e7278 },
];
const POCO: Finish[] = [
  { name: "Жёлтый", frame: 0x1a1a1c, glass: 0x121214, accent: 0xffd60a },
  { name: "Чёрный", frame: 0x222226, glass: 0x101012, accent: 0xffd60a },
  { name: "Синий", frame: 0x1a2740, glass: 0x142038, accent: 0xffd60a },
];
const NOTHING: Finish[] = [
  { name: "Белый", frame: 0xd8d8dc, glass: 0xf2f2f4, accent: 0xffffff },
  { name: "Чёрный", frame: 0x1c1c1e, glass: 0x2a2a2c, accent: 0xf5f5f5 },
];
const ROG: Finish[] = [
  { name: "Чёрный", frame: 0x141416, glass: 0x0e0e10, accent: 0xff2a2a },
  { name: "Белый", frame: 0xe6e6ea, glass: 0xf4f4f6, accent: 0xff2a2a },
];
const GEN: Finish[] = [
  { name: "Чёрный", frame: 0x2e3136, glass: 0x1a1c20, accent: 0x3e4248 },
  { name: "Серебро", frame: 0xc2c6cc, glass: 0xd8dce2, accent: 0xa0a6ae },
  { name: "Синий", frame: 0x24344c, glass: 0x2e4464, accent: 0x1c2a3e },
  { name: "Зелёный", frame: 0x24362e, glass: 0x31483c, accent: 0x1c2c24 },
  { name: "Золото", frame: 0xb8a48a, glass: 0xd4c4aa, accent: 0x8c7c66 },
];

export function hex(n: number) {
  return "#" + n.toString(16).padStart(6, "0");
}

function pick(list: Finish[], i: number) {
  return list[((i % list.length) + list.length) % list.length];
}

export function finishFor(brand: string, model: string, color: number): Finish {
  if (brand === "iPhone") return pick(IP, color);
  if (brand === "Samsung") return pick(SAM, color);
  if (brand === "Google") return pick(PX, color);
  if (brand === "Xiaomi" || brand === "Redmi") return pick(MI, color);
  if (brand === "Poco") return pick(POCO, color);
  if (brand === "Nothing") return pick(NOTHING, color);
  if (brand === "Asus" && model.startsWith("ROG")) return pick(ROG, color);
  return pick(GEN, color);
}

function camBox(
  shape: Cam["shape"],
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  lenses: Lens[],
  flash?: { x: number; y: number },
): Cam {
  return { shape, x, y, w, h, r, lenses, flash };
}

function iphoneCam(model: string, w: number, h: number): Cam {
  const x = -w / 2 + 0.2;
  const y = h / 2 - 0.27;
  if (model === "8" || model === "XR" || model.startsWith("SE")) {
    const cx = -w / 2 + 0.15;
    const cy = h / 2 - 0.16;
    return camBox("single", cx, cy, 0.12, 0.12, 0.06, [{ x: cx, y: cy, r: 0.038 }]);
  }
  if (model === "XS" || model === "11") {
    return camBox("dual", x, y, 0.2, 0.28, 0.05, [
      { x: x, y: y + 0.06, r: 0.034 },
      { x: x, y: y - 0.06, r: 0.034 },
    ], { x: x + 0.06, y: y });
  }
  if (model.includes("Pro")) {
    return camBox("triple", x, y, 0.26, 0.26, 0.06, [
      { x: x - 0.05, y: y + 0.05, r: 0.032 },
      { x: x + 0.05, y: y + 0.05, r: 0.032 },
      { x: x - 0.05, y: y - 0.05, r: 0.038 },
    ], { x: x + 0.055, y: y - 0.05 });
  }
  return camBox("dual", x, y, 0.24, 0.24, 0.055, [
    { x: x - 0.045, y: y + 0.045, r: 0.034 },
    { x: x + 0.045, y: y - 0.045, r: 0.034 },
  ], { x: x + 0.05, y: y + 0.05 });
}

function samsungCam(model: string, w: number, h: number): Cam {
  if (model.includes("Ultra") || model.startsWith("Note")) {
    const x = -w / 2 + 0.2;
    const y = h / 2 - 0.32;
    return camBox("island", x, y, 0.3, 0.42, 0.07, [
      { x: x - 0.06, y: y + 0.1, r: 0.038 },
      { x: x + 0.06, y: y + 0.1, r: 0.03 },
      { x: x - 0.06, y: y - 0.02, r: 0.03 },
      { x: x + 0.06, y: y - 0.1, r: 0.026 },
    ], { x: x + 0.06, y: y - 0.02 });
  }
  const x = -w / 2 + 0.15;
  const y = h / 2 - 0.34;
  const lenses = model.startsWith("A")
    ? [
        { x, y: y + 0.08, r: 0.032 },
        { x, y: y - 0.04, r: 0.026 },
      ]
    : [
        { x, y: y + 0.1, r: 0.034 },
        { x, y: y, r: 0.03 },
        { x, y: y - 0.1, r: 0.026 },
      ];
  return camBox("pill", x, y, 0.16, model.startsWith("A") ? 0.32 : 0.42, 0.08, lenses, {
    x: x,
    y: y + (model.startsWith("A") ? 0.14 : 0.16),
  });
}

export function layoutFor(brand: string, model: string, base = 20000): PhoneLayout {
  const thin = base > 60000 ? 0.078 : base < 10000 ? 0.098 : 0.086;
  let w = 0.74;
  let h = 1.56;
  let radius = 0.1;
  let d = thin;
  let front: PhoneLayout["front"] = "punch";
  let port: PhoneLayout["port"] = "usbc";
  let screws: 2 | 4 = 4;
  let opensFront = false;
  let board: PhoneLayout["board"] = "rect";
  let hinge = false;
  let glyph = false;
  let rog = false;
  let poco = brand === "Poco";
  let cam: Cam;

  if (brand === "iPhone") {
    const num = parseInt(model, 10);
    const pro = model.includes("Pro");
    const plus = model.includes("Plus") || model.includes("Max");
    const mini = model.includes("mini");
    const se = model === "8" || model.startsWith("SE");
    opensFront = true;
    screws = 2;
    board = "L";
    port = !Number.isNaN(num) && num >= 15 ? "usbc" : "lightning";
    if (se) {
      w = 0.68;
      h = 1.38;
      radius = 0.085;
      d = 0.1;
      front = "home";
    } else if (mini) {
      w = 0.64;
      h = 1.32;
      radius = 0.1;
      front = "notch";
    } else if (plus) {
      w = 0.78;
      h = 1.64;
      radius = 0.11;
      front = num >= 15 || (num >= 14 && pro) ? "island" : "notch";
    } else {
      w = 0.715;
      h = 1.5;
      radius = 0.105;
      front = num >= 15 || (num >= 14 && pro) ? "island" : "notch";
    }
    if (Number.isNaN(num) && !se) front = "notch";
    cam = iphoneCam(model, w, h);
  } else if (brand === "Samsung") {
    if (model.includes("Flip")) {
      w = 0.73;
      h = 0.92;
      radius = 0.11;
      hinge = true;
    } else if (model.includes("Fold")) {
      w = 0.67;
      h = 1.58;
      radius = 0.09;
    } else if (model.includes("Ultra") || model.startsWith("Note")) {
      w = 0.79;
      h = 1.66;
      radius = 0.09;
    } else if (model.startsWith("A")) {
      w = 0.76;
      h = 1.64;
      radius = 0.1;
      d = Math.max(d, 0.092);
    } else {
      w = 0.73;
      h = 1.55;
      radius = 0.09;
    }
    front = "punch";
    cam = samsungCam(model, w, h);
  } else if (brand === "Google") {
    w = 0.72;
    h = 1.55;
    radius = 0.1;
    const y = h / 2 - 0.15;
    cam = camBox("bar", 0, y, w - 0.12, 0.2, 0.07, [
      { x: -0.12, y, r: 0.04 },
      { x: 0.06, y, r: 0.048 },
    ], { x: 0.2, y });
    front = "punch";
  } else if (brand === "Xiaomi" || brand === "Redmi") {
    w = brand === "Redmi" ? 0.76 : 0.74;
    h = brand === "Redmi" ? 1.64 : 1.58;
    radius = 0.095;
    if (model.includes("Ultra")) {
      const x = -w / 2 + 0.24;
      const y = h / 2 - 0.28;
      cam = camBox("circle", x, y, 0.4, 0.4, 0.2, [
        { x: x - 0.06, y: y + 0.05, r: 0.04 },
        { x: x + 0.06, y: y + 0.05, r: 0.032 },
        { x: x, y: y - 0.07, r: 0.032 },
      ], { x: x + 0.1, y: y - 0.02 });
    } else {
      const x = -w / 2 + 0.18;
      const y = h / 2 - 0.26;
      cam = camBox("island", x, y, 0.26, 0.3, 0.05, [
        { x: x - 0.04, y: y + 0.06, r: 0.032 },
        { x: x + 0.04, y: y + 0.06, r: 0.026 },
        { x: x - 0.04, y: y - 0.05, r: 0.026 },
      ], { x: x + 0.05, y: y - 0.05 });
    }
    front = "punch";
  } else if (brand === "Nothing") {
    w = 0.74;
    h = 1.58;
    radius = 0.1;
    glyph = true;
    const y = h / 2 - 0.22;
    cam = camBox("pill", 0, y, 0.42, 0.16, 0.08, [
      { x: -0.08, y, r: 0.034 },
      { x: 0.08, y, r: 0.034 },
    ], { x: 0.18, y });
    front = "punch";
  } else if (brand === "OnePlus" || brand === "OPPO" || brand === "Realme") {
    w = 0.74;
    h = 1.6;
    radius = 0.1;
    const x = -w / 2 + 0.2;
    const y = h / 2 - 0.24;
    cam = camBox("circle", x, y, 0.28, 0.28, 0.14, [
      { x, y: y + 0.02, r: 0.04 },
      { x: x - 0.06, y: y - 0.05, r: 0.026 },
    ], { x: x + 0.07, y: y - 0.04 });
    front = "punch";
  } else if (brand === "Asus" && model.startsWith("ROG")) {
    w = 0.77;
    h = 1.66;
    radius = 0.04;
    d = 0.1;
    rog = true;
    const x = 0;
    const y = h / 2 - 0.28;
    cam = camBox("island", x, y, 0.34, 0.28, 0.04, [
      { x: x - 0.06, y, r: 0.036 },
      { x: x + 0.06, y, r: 0.03 },
    ], { x: x, y: y - 0.08 });
    front = "punch";
  } else if (brand === "Sony") {
    w = 0.66;
    h = 1.7;
    radius = 0.06;
    const x = -w / 2 + 0.14;
    const y = h / 2 - 0.28;
    cam = camBox("pill", x, y, 0.14, 0.36, 0.07, [
      { x, y: y + 0.08, r: 0.03 },
      { x, y: y - 0.06, r: 0.026 },
    ]);
    front = "punch";
  } else if (brand === "Motorola" && model.startsWith("Razr")) {
    w = 0.74;
    h = 0.94;
    radius = 0.11;
    hinge = true;
    const y = h / 2 - 0.16;
    cam = camBox("dual", 0, y, 0.28, 0.14, 0.06, [
      { x: -0.06, y, r: 0.03 },
      { x: 0.06, y, r: 0.03 },
    ]);
    front = "punch";
  } else if (brand === "Poco") {
    w = 0.75;
    h = 1.62;
    radius = 0.08;
    const x = -w / 2 + 0.2;
    const y = h / 2 - 0.26;
    cam = camBox("island", x, y, 0.32, 0.32, 0.04, [
      { x: x - 0.05, y: y + 0.05, r: 0.032 },
      { x: x + 0.05, y: y + 0.05, r: 0.026 },
      { x: x - 0.05, y: y - 0.06, r: 0.026 },
    ], { x: x + 0.06, y: y - 0.06 });
    front = "punch";
  } else {
    const x = -w / 2 + 0.17;
    const y = h / 2 - 0.28;
    cam = camBox("pill", x, y, 0.16, 0.36, 0.08, [
      { x, y: y + 0.08, r: 0.03 },
      { x, y: y - 0.06, r: 0.026 },
    ], { x, y: y + 0.16 });
  }

  return {
    w, h, d, radius, wall: 0.03, screws, opensFront, board, port, front, cam, hinge, glyph, rog, poco,
  };
}
