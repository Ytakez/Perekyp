import { useEffect, useState } from "react";
import {
  Cpu,
  Handshake,
  Moon,
  Search,
  Smartphone,
  Store,
  Sun,
  Tag,
  Warehouse,
  Wrench,
} from "lucide-react";
import { CPU, COND, GOAL } from "./catalog";
import { PhoneGlyph } from "./PhoneGlyph";
import { StageView, focusView } from "./Stage";
import {
  allRoms,
  baseTier,
  batCost,
  benchPhone,
  boardCost,
  cpuCost,
  fmt,
  fullCost,
  hw,
  pname,
  phoneValue,
  romFits,
  romRisk,
  screenCost,
  worth,
} from "./logic";
import {
  addSlot,
  buy,
  checkImei,
  dropJob,
  failJob,
  finishJob,
  fixBat,
  fixBoard,
  fixScreen,
  flashRom,
  fullFix,
  haggle,
  hydrate,
  listPhone,
  lookPhone,
  makeRom,
  newDay,
  resetGame,
  seal,
  sellShop,
  setTab,
  setTool,
  takeJob,
  unlist,
  upgradeCpu,
  useGame,
  workshop,
} from "./store";
import { unlockAudio } from "./sfx";
import type { Phone, Tab, Tool } from "./types";

const TABS: { id: Tab; label: string; icon: typeof Store }[] = [
  { id: "mk", label: "Рынок", icon: Store },
  { id: "inv", label: "Склад", icon: Warehouse },
  { id: "olx", label: "OLX", icon: Tag },
  { id: "svc", label: "Сервис", icon: Wrench },
  { id: "shop", label: "Цех", icon: Cpu },
];

const TOOLS: { id: Tool; label: string }[] = [
  { id: "hand", label: "Рука" },
  { id: "driver", label: "Винты" },
  { id: "spudger", label: "Лопатка" },
  { id: "tweezer", label: "Пинцет" },
];

function Stars({ value }: { value: number }) {
  const n = Math.round(value);
  return (
    <span className="inline-flex items-center gap-1 text-sm text-mut">
      <span className="text-ink">{n > 0 ? "★★★★★".slice(0, n) : ""}</span>
      <span className="text-line">{"★★★★★".slice(0, 5 - n)}</span>
      {value.toFixed(1)}
    </span>
  );
}

function Price({ n }: { n: number }) {
  return <span className="price">{fmt(n)}</span>;
}

function ListForm({ id, hint }: { id: number; hint: number }) {
  const [v, setV] = useState(String(hint));
  return (
    <form
      className="flex flex-wrap gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        listPhone(id, Number(String(v).replace(/\s/g, "")));
      }}
    >
      <input className="inp" inputMode="numeric" value={v} onChange={(e) => setV(e.target.value)} aria-label="Цена на OLX" />
      <button className="btn-go" type="submit">
        На OLX
      </button>
    </form>
  );
}

function PhoneCard({
  phone,
  mode,
}: {
  phone: Phone;
  mode: "mk" | "inv";
}) {
  const s = useGame();
  const value = phoneValue(s, phone, true);
  const fair = phoneValue(s, phone, false);
  return (
    <article className="card" style={{ borderLeftColor: COND[phone.c].c }}>
      <div className="flex gap-3">
        <PhoneGlyph phone={phone} />
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="truncate font-display text-base">{pname(phone)}</h3>
            <span className="chip" style={{ borderColor: COND[phone.c].c }}>
              {COND[phone.c].n}
            </span>
          </div>
          {mode === "mk" ? (
            <>
              <Price n={phone.ask} />
              <p className="mt-1 text-sm text-mut">
                <Stars value={phone.sellerR} /> · {phone.sellerN} отзывов · индекс {(s.idx[phone.brand] ?? 1).toFixed(2)}
              </p>
              {phone.seen ? (
                <p className={phone.fake ? "bad" : "ok"}>{phone.fake ? phone.fk : "IMEI чистый"}</p>
              ) : null}
            </>
          ) : (
            <>
              <p className="mt-1 text-sm text-mut">
                {phone.job ? "Заказ клиента" : `Куплен за ${fmt(phone.paid)}`}
                {phone.seal ? " · пломба" : ""}
                {phone.brick ? " · кирпич" : ""}
              </p>
              <p className="text-sm">
                Оценка <b>{fmt(value)}</b>
                {phone.fake ? " с учётом подделки" : ""} · скупка {fmt(Math.round(value * 0.7))}
              </p>
              {phone.listed ? <p className="ok">На OLX за {fmt(phone.listed)}</p> : null}
              <p className="text-sm text-mut">
                {hw(s, phone).rom.n} · {CPU[hw(s, phone).t].n}
              </p>
            </>
          )}
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {mode === "mk" ? (
          <>
            <button className="btn-go" type="button" onClick={() => buy(phone.id)}>
              Купить
            </button>
            <button className="btn" type="button" onClick={() => haggle(phone.id)} disabled={phone.haggled}>
              <Handshake size={16} /> Торг
            </button>
            <button className="btn" type="button" onClick={() => checkImei(phone.id)} disabled={phone.seen}>
              <Search size={16} /> IMEI 250 ₽
            </button>
            <button className="btn" type="button" onClick={() => lookPhone(phone.id)}>
              <Smartphone size={16} /> В 3D
            </button>
          </>
        ) : (
          <>
            <button className="btn-go" type="button" onClick={() => workshop(phone.id)}>
              В цех
            </button>
            {phone.job ? null : (
              <button className="btn" type="button" onClick={() => sellShop(phone.id)}>
                Скупка
              </button>
            )}
            {phone.listed ? (
              <button className="btn" type="button" onClick={() => unlist(phone.id)}>
                Снять
              </button>
            ) : phone.job ? null : (
              <ListForm id={phone.id} hint={Math.round(fair * 1.05)} />
            )}
          </>
        )}
      </div>
    </article>
  );
}

export function Game() {
  const s = useGame();
  const ctx = benchPhone(s);
  const [arm, setArm] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const onDown = () => unlockAudio();
    window.addEventListener("pointerdown", onDown, { capture: true });
    setDark(document.documentElement.classList.contains("dark"));
    return () => window.removeEventListener("pointerdown", onDown, { capture: true });
  }, []);

  const w = worth(s);
  const goalPct = Math.max(0, Math.min(100, (w / GOAL) * 100));
  const slotCost = (s.slots - 3) * 6000;
  const screwsLeft = s.bench.screwsIn.filter(Boolean).length;
  const phone = ctx?.phone ?? null;
  const own = ctx?.own ?? false;
  const tier = phone ? hw(s, phone).t : 0;

  return (
    <div className="pb-24">
      <header className="sticky top-0 z-20 border-b border-line bg-bg">
        <div className="mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <div className="font-display text-2xl leading-none">{fmt(s.cash)}</div>
            <p className="mt-1 text-sm text-mut">
              День {s.day} · имущество {fmt(w)} · склад {s.inv.length}/{s.slots}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="btn icon"
              type="button"
              aria-label={dark ? "Светлая тема" : "Тёмная тема"}
              onClick={() => {
                const next = document.documentElement.classList.toggle("dark");
                localStorage.setItem("perekup-theme", next ? "dark" : "light");
                setDark(next);
              }}
            >
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button className="btn-go" type="button" onClick={() => newDay()}>
              Новый день
            </button>
          </div>
        </div>
        <div className="mx-auto max-w-2xl px-4 pb-3">
          <div className="bar" aria-hidden>
            <i style={{ width: `${goalPct}%` }} />
          </div>
          <p className="mt-1 text-sm text-mut">
            Цель {fmt(GOAL)}
            {s.won ? " · взята" : ""} · рейтинг {s.rating.toFixed(1)} · продано {s.sold}
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 pt-3">
        {s.msg ? <p className="msg">{s.msg}</p> : null}

        {s.tab === "mk" ? (
          <>
            <p className="mb-3 text-sm text-mut">Восемь объявлений. Торгуйся, проверяй IMEI и крути корпус в цехе до покупки.</p>
            {s.mk.map((p) => (
              <PhoneCard key={p.id} phone={p} mode="mk" />
            ))}
          </>
        ) : null}

        {s.tab === "inv" ? (
          <>
            <div className="mb-3 flex items-center justify-between gap-2">
              <p className="text-sm text-mut">Свои аппараты и заказы сервиса.</p>
              <button className="btn" type="button" onClick={() => addSlot()} disabled={s.slots >= 12}>
                +место {fmt(slotCost)}
              </button>
            </div>
            {s.inv.length === 0 ? <p className="card">Склад пуст. На рынке как раз есть из чего выбрать.</p> : null}
            {s.inv.map((p) => (
              <PhoneCard key={p.id} phone={p} mode="inv" />
            ))}
          </>
        ) : null}

        {s.tab === "olx" ? (
          <>
            <p className="mb-3 text-sm text-mut">
              Покупатели смотрят цену, рейтинг {s.rating.toFixed(1)} и пломбу. Подделка может обернуться спором на следующий день.
            </p>
            {s.inv.filter((p) => p.listed).length === 0 ? <p className="card">Ничего не выставлено. Цену ставишь на складе.</p> : null}
            {s.inv
              .filter((p) => p.listed)
              .map((p) => (
                <PhoneCard key={p.id} phone={p} mode="inv" />
              ))}
          </>
        ) : null}

        {s.tab === "svc" ? (
          <>
            <p className="mb-3 text-sm text-mut">
              Сделано заказов: {s.doneJobs}. Выручка сервиса {fmt(s.svcEarn)}.
            </p>
            {s.jobs.length === 0 ? <p className="card">Тишина. Новые заявки приходят со следующим днём.</p> : null}
            {s.jobs.map((j) => {
              const live = s.inv.find((p) => p.id === j.phone.id) ?? j.phone;
              return (
                <article key={j.id} className="card" style={{ borderLeftColor: COND[live.c].c }}>
                  <div className="flex gap-3">
                    <PhoneGlyph phone={live} />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-display text-base">{j.cust.name}</h3>
                      <p className="text-sm text-mut">{j.cust.phone}</p>
                      <p className="mt-1">
                        {pname(live)} — {j.prob.n}
                      </p>
                      <Price n={j.pay} />
                      <p className="text-sm text-mut">{j.status === "work" ? "В работе" : "Ждёт ответ"}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {j.status === "wait" ? (
                      <>
                        <button className="btn-go" type="button" onClick={() => takeJob(j.id)}>
                          Принять
                        </button>
                        <button className="btn" type="button" onClick={() => dropJob(j.id)}>
                          Отказ
                        </button>
                      </>
                    ) : (
                      <>
                        <button className="btn-go" type="button" onClick={() => workshop(live.id)}>
                          В цех
                        </button>
                        <button className="btn" type="button" onClick={() => finishJob(j.id)}>
                          Выдать
                        </button>
                        <button className="btn" type="button" onClick={() => failJob(j.id)}>
                          Вернуть
                        </button>
                      </>
                    )}
                  </div>
                </article>
              );
            })}
          </>
        ) : null}

        {s.tab === "shop" ? (
          <>
            <div className="stage-wrap">
              <StageView />
              <div className="stage-caption">
                <div className="font-display text-sm text-onbench">{phone ? pname(phone) : "Стол пуст"}</div>
                <div className="text-xs text-onbenchmut">
                  {phone
                    ? `${COND[phone.c].n}${phone.d.b ? " · батарея вздута" : ""}${phone.d.w ? " · окислы" : ""}${phone.fake && phone.seen ? " · " + phone.fk : ""}`
                    : "Выбери телефон на рынке или складе"}
                </div>
              </div>
              <div className="stage-views">
                <button type="button" className="btn tiny" onClick={() => focusView("back")}>
                  Крышка
                </button>
                <button type="button" className="btn tiny" onClick={() => focusView("front")}>
                  Экран
                </button>
                <button type="button" className="btn tiny" onClick={() => focusView("inside")}>
                  Внутрь
                </button>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-4 gap-2">
              {TOOLS.map((t) => (
                <button key={t.id} type="button" className={s.bench.tool === t.id ? "btn-go" : "btn"} onClick={() => setTool(t.id)}>
                  {t.label}
                </button>
              ))}
            </div>
            <p className="mt-2 text-sm text-mut">
              Винты {s.bench.screwsIn.length - screwsLeft}/{s.bench.screwsIn.length}
              {s.bench.open ? " · крышка снята" : " · закрыт"}
              {s.bench.batConn ? " · шлейф на месте" : " · шлейф снят"}
              {own ? "" : phone ? " · чужой, только смотреть" : ""}
            </p>

            {phone && own ? (
              <div className="mt-3 flex flex-wrap gap-2">
                {phone.d.b ? (
                  <button className="btn" type="button" onClick={() => fixBat(phone.id)}>
                    Новая АКБ {fmt(batCost(phone))}
                  </button>
                ) : null}
                {phone.d.s || phone.c === 3 ? (
                  <button className="btn" type="button" onClick={() => fixScreen(phone.id)}>
                    Экран {fmt(screenCost(phone))}
                  </button>
                ) : null}
                {phone.d.f || phone.brick || phone.d.w || phone.c === 4 ? (
                  <button className="btn" type="button" onClick={() => fixBoard(phone.id)}>
                    Плата {fmt(boardCost(phone))}
                  </button>
                ) : null}
                {phone.c > 1 || phone.brick ? (
                  <button className="btn-go" type="button" onClick={() => fullFix(phone.id)}>
                    Полный ремонт {fmt(fullCost(phone))}
                  </button>
                ) : null}
                <button className="btn" type="button" onClick={() => seal(phone.id)} disabled={!!phone.seal || phone.job}>
                  Пломба 500 ₽
                </button>
                {tier < 4 ? (
                  <button className="btn" type="button" onClick={() => upgradeCpu()}>
                    Чип {CPU[tier + 1].n} · {fmt(cpuCost(tier + 1))}
                  </button>
                ) : null}
              </div>
            ) : null}

            {phone && !own ? (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Price n={phone.ask} />
                <button className="btn-go" type="button" onClick={() => buy(phone.id)}>
                  Купить с витрины
                </button>
              </div>
            ) : null}

            {phone ? (
              <details className="mt-4" open>
                <summary className="cursor-pointer font-display text-sm">Прошивки · сейчас {hw(s, phone).rom.n}</summary>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button className="btn" type="button" onClick={() => makeRom(false)}>
                    Своя тихая
                  </button>
                  <button className="btn" type="button" onClick={() => makeRom(true)}>
                    Своя злая
                  </button>
                </div>
                <ul className="mt-2">
                  {allRoms(s).map((rom) => {
                    const risk = Math.round(romRisk(rom, phone.brand) * 100);
                    const fit = romFits(rom, phone.brand);
                    return (
                      <li key={rom.id} className="flex items-center justify-between gap-2 border-b border-line py-2">
                        <div className="min-w-0">
                          <div className="truncate text-sm font-semibold">{rom.n}</div>
                          <div className="text-xs text-mut">
                            {rom.d} · ×{rom.p.toFixed(2)} · риск {risk}%{fit ? "" : " · не её вендор"}
                            {rom.c ? ` · ${fmt(rom.c)}` : ""}
                          </div>
                        </div>
                        <button className="btn" type="button" disabled={!own || !!s.boot} onClick={() => flashRom(rom.id)}>
                          Шить
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </details>
            ) : null}
          </>
        ) : null}

        <details className="mt-4 mb-6">
          <summary className="cursor-pointer text-sm text-mut">Журнал и сброс</summary>
          <div className="mt-2">
            {s.log.map((line, i) => (
              <p key={i} className="border-b border-line py-2 text-sm">
                {line}
              </p>
            ))}
            <button
              className="btn mt-3"
              type="button"
              onClick={() => {
                if (!arm) {
                  setArm(true);
                  return;
                }
                resetGame();
                setArm(false);
              }}
            >
              {arm ? "Точно начать заново?" : "Сбросить лавку"}
            </button>
          </div>
        </details>
      </main>

      <nav className="dock">
        <div className="mx-auto flex max-w-2xl gap-1">
          {TABS.map((t) => {
            const Icon = t.icon;
            const on = s.tab === t.id;
            return (
              <button key={t.id} type="button" className={on ? "dock-btn on" : "dock-btn"} onClick={() => setTab(t.id)}>
                <Icon size={18} />
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export function Boot() {
  const [on, setOn] = useState(false);
  useEffect(() => {
    hydrate();
    setOn(true);
  }, []);
  if (!on) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-8">
        <h1 className="font-display text-3xl">Перекуп</h1>
        <p className="mt-2 text-mut">Открываем лавку…</p>
      </main>
    );
  }
  return <Game />;
}
