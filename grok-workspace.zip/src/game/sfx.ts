let ctx: AudioContext | null = null;

export function unlockAudio() {
  if (typeof window === "undefined") return;
  if (!ctx) ctx = new AudioContext();
  if (ctx.state === "suspended") void ctx.resume();
}

export function sfx(kind: "screw" | "open" | "cash" | "err" | "click") {
  if (!ctx || ctx.state !== "running") return;
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.connect(g);
  g.connect(ctx.destination);
  const map = {
    screw: [740, 0.06, "square", 0.03],
    open: [180, 0.14, "sine", 0.04],
    cash: [880, 0.12, "triangle", 0.04],
    err: [140, 0.12, "sawtooth", 0.03],
    click: [520, 0.04, "sine", 0.03],
  } as const;
  const [freq, dur, type, vol] = map[kind];
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (kind === "cash") o.frequency.exponentialRampToValueAtTime(1320, t + dur);
  if (kind === "screw") o.frequency.exponentialRampToValueAtTime(220, t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.start(t);
  o.stop(t + dur + 0.02);
}
