import type { Problem, Rom } from "./types";

export const RAW: Record<string, string> = {
  iPhone:
    "8 6;XR 11;XS 12;SE 2020 10;SE 2022 16;11 18;11 Pro 24;12 mini 20;12 26;12 Pro 32;13 mini 28;13 35;13 Pro 45;13 Pro Max 48;14 42;14 Pro 55;14 Pro Max 62;15 58;15 Plus 62;15 Pro 72;15 Pro Max 82;16 75;16 Plus 80;16 Pro 95;16 Pro Max 105",
  Samsung:
    "A15 11;A25 14;A35 19;A54 20;A55 27;A56 32;S20 18;S21 24;S22 30;S23 42;S23+ 48;S23 Ultra 58;S24 55;S24+ 62;S24 Ultra 85;S25 70;S25 Ultra 98;Note 20 Ultra 25;Z Flip5 45;Z Flip6 55;Z Fold5 75;Z Fold6 95",
  Xiaomi:
    "Mi 11 Lite 10;12 20;12T 22;13 Lite 17;13 32;13T 28;13T Pro 35;14 48;14T 38;14T Pro 42;14 Ultra 72;Mix Fold 3 60;Mix Fold 4 85",
  Redmi:
    "12C 5.5;13C 7.5;14C 8;Note 10 7;Note 11 9;Note 12 12;Note 12 Pro 16;Note 13 14;Note 13 Pro 18;Note 13 Pro+ 24;Note 14 16;Note 14 Pro 21;Note 14 Pro+ 28;K60 20;K70 35;K70 Pro 45",
  Poco: "M5 8;M6 10;X5 Pro 17;X6 22;X6 Pro 26;F5 28;F5 Pro 34;F6 32;F6 Pro 36",
  Meizu: "Note 9 6;16T 8;17 14;18 18;20 24;20 Pro 30;21 32;21 Pro 38",
  OnePlus:
    "8T 14;Nord CE 3 Lite 11;Nord 3 24;Nord 4 28;9 Pro 28;10 Pro 30;11 40;11R 34;12R 36;12 52;13 68",
  Google:
    "Pixel 6a 14;Pixel 7a 22;Pixel 7 30;Pixel 7 Pro 42;Pixel 8 40;Pixel 8a 28;Pixel 8 Pro 50;Pixel 9 55;Pixel 9 Pro 72",
  Honor: "90 25;90 Lite 16;200 32;Magic5 40;Magic6 Pro 60;Magic7 70",
  Huawei: "Nova 11 22;P50 28;Mate 50 40;P60 Pro 50;Mate 60 55;Mate 60 Pro 70",
  Realme: "GT Neo 5 24;GT 5 28;GT 6 36;12 Pro+ 30;13 Pro 28",
  Nothing: "Phone 1 22;Phone 2 35;Phone 2a 24;Phone 3a 28",
  Asus: "ROG Phone 7 55;ROG Phone 8 72;Zenfone 10 38",
  Sony: "Xperia 1 V 48;Xperia 5 V 40;Xperia 10 VI 22",
  Motorola: "Edge 40 28;Edge 50 Pro 36;Razr 40 42",
  Vivo: "X100 45;X100 Pro 62;V30 28",
  OPPO: "Find X6 40;Find X7 55;Reno 12 26",
};

export const MODELS: Record<string, [string, number][]> = {};
for (const k in RAW) {
  MODELS[k] = RAW[k].split(";").map((s) => {
    const i = s.lastIndexOf(" ");
    return [s.slice(0, i), Math.round(parseFloat(s.slice(i + 1)) * 1000)];
  });
}

export const BRANDS = Object.keys(MODELS);

export const COND = [
  { n: "Идеал", m: 1, c: "#1f9d6b" },
  { n: "Хорошее", m: 0.86, c: "#2f8fb0" },
  { n: "Потёртый", m: 0.72, c: "#c9961a" },
  { n: "Разбит экран", m: 0.5, c: "#d9701f" },
  { n: "Не включается", m: 0.3, c: "#c8302f" },
] as const;

export const FK = ["Реплика", "Блокировка аккаунта", "Серый IMEI"];

export const GOAL = 300000;

export const CPU = [
  { n: "Helio G85 / A12", mult: 1 },
  { n: "Snapdragon 695 / A14", mult: 1.15 },
  { n: "Snapdragon 8 Gen 1 / A16", mult: 1.35 },
  { n: "Snapdragon 8 Gen 3 / A17 Pro", mult: 1.55 },
  { n: "Snapdragon 8 Elite / A18 Pro", mult: 1.8 },
];

export const NAMES_F = ["Алексей", "Дмитрий", "Иван", "Сергей", "Андрей", "Максим", "Артём", "Никита", "Кирилл", "Егор", "Олег", "Павел", "Роман", "Тимур", "Юрий"];
export const NAMES_L = ["Иванов", "Смирнов", "Кузнецов", "Попов", "Васильев", "Петров", "Соколов", "Михайлов", "Новиков", "Фёдоров", "Морозов", "Волков", "Алексеев", "Лебедев", "Семёнов"];
export const NAMES_W = ["Анна", "Мария", "Елена", "Ольга", "Наталья", "Татьяна", "Екатерина", "Ирина", "Светлана", "Юлия", "Алина", "Дарья", "Полина", "Виктория", "Ксения"];

export const PROBS: Problem[] = [
  { id: "screen", n: "Разбит экран", c: 3, fix: 1, pay: 0.22 },
  { id: "bat", n: "Быстро садится батарея", c: 1, fix: 1, pay: 0.1 },
  { id: "dead", n: "Не включается", c: 4, fix: 1, pay: 0.28 },
  { id: "boot", n: "Бесконечная загрузка", c: 4, fix: 1, pay: 0.18 },
  { id: "lines", n: "Полосы на дисплее", c: 2, fix: 1, pay: 0.15 },
  { id: "slow", n: "Тормозит / греется", c: 1, fix: 0, pay: 0.12 },
  { id: "water", n: "После воды", c: 4, fix: 1, pay: 0.3 },
  { id: "charge", n: "Не заряжается", c: 2, fix: 1, pay: 0.14 },
];

const th = (a: string, b: string, c: string, d: string): Rom["th"] => [a, b, c, d];

export const ROMS: Rom[] = [
  { id: "stock", n: "Официальная (сток)", b: null, r: 0, p: 1, c: 0, d: "Заводская прошивка", th: th("#1b4fd8", "#7b2ff7", "#ff5f6d", "#0a84ff") },
  { id: "debloat", n: "Сток debloat", b: null, r: 0.05, p: 1.08, c: 500, d: "Очищенная официальная", th: th("#2b5876", "#4e4376", "#1a1a2e", "#4fc3f7") },
  { id: "lineage21", n: "LineageOS 21", b: null, r: 0.08, p: 1.12, c: 0, d: "Чистый AOSP", th: th("#167c80", "#0d5c60", "#102a2c", "#3ddc84") },
  { id: "lineage20", n: "LineageOS 20", b: null, r: 0.06, p: 1.08, c: 0, d: "AOSP Android 13", th: th("#0f766e", "#134e4a", "#042f2e", "#2dd4bf") },
  { id: "pixelxp", n: "Pixel Experience", b: null, r: 0.1, p: 1.15, c: 0, d: "Как у Google Pixel", th: th("#1a73e8", "#174ea6", "#0d47a1", "#8ab4f8") },
  { id: "evox", n: "Evolution X", b: null, r: 0.12, p: 1.18, c: 0, d: "Material You + твики", th: th("#7c3aed", "#a855f7", "#4c1d95", "#c4b5fd") },
  { id: "crdroid", n: "crDroid 10", b: null, r: 0.1, p: 1.14, c: 0, d: "Баланс фич", th: th("#2563eb", "#1d4ed8", "#1e3a8a", "#60a5fa") },
  { id: "arrow", n: "ArrowOS", b: null, r: 0.09, p: 1.11, c: 0, d: "Лёгкий и быстрый", th: th("#ea580c", "#c2410c", "#7c2d12", "#fdba74") },
  { id: "havoc", n: "Havoc-OS", b: null, r: 0.11, p: 1.13, c: 0, d: "Много твиков", th: th("#dc2626", "#991b1b", "#450a0a", "#fca5a5") },
  { id: "paranoid", n: "Paranoid Android", b: null, r: 0.1, p: 1.16, c: 0, d: "Качественный кастом", th: th("#4f46e5", "#3730a3", "#1e1b4b", "#a5b4fc") },
  { id: "graphene", n: "GrapheneOS", b: "Google", r: 0.05, p: 1.05, c: 0, d: "Макс. безопасность", th: th("#111827", "#1f2937", "#030712", "#6ee7b7") },
  { id: "calyx", n: "CalyxOS", b: "Google", r: 0.06, p: 1.04, c: 0, d: "Приватность", th: th("#14532d", "#166534", "#052e16", "#86efac") },
  { id: "miui14", n: "MIUI 14 Global", b: "Xiaomi", r: 0.07, p: 1.02, c: 0, d: "Xiaomi оболочка", th: th("#f97316", "#ea580c", "#7c2d12", "#fdba74") },
  { id: "hyperos", n: "HyperOS", b: "Xiaomi", r: 0.08, p: 1.06, c: 0, d: "Новая Xiaomi", th: th("#0ea5e9", "#0284c7", "#0c4a6e", "#7dd3fc") },
  { id: "oneui6", n: "One UI 6", b: "Samsung", r: 0.08, p: 1.05, c: 0, d: "Samsung One UI", th: th("#3b82f6", "#1e40af", "#172554", "#93c5fd") },
  { id: "oneui5", n: "One UI 5.1", b: "Samsung", r: 0.05, p: 1, c: 0, d: "Стабильная One UI", th: th("#2563eb", "#1e3a8a", "#0f172a", "#60a5fa") },
  { id: "coloros14", n: "ColorOS 14", b: "OnePlus", r: 0.09, p: 1.04, c: 0, d: "OPPO/OnePlus", th: th("#16a34a", "#15803d", "#052e16", "#86efac") },
  { id: "oxygen", n: "OxygenOS 14", b: "OnePlus", r: 0.07, p: 1.08, c: 0, d: "Классический Oxygen", th: th("#ef4444", "#b91c1c", "#450a0a", "#fca5a5") },
  { id: "nothingos", n: "Nothing OS 2.5", b: null, r: 0.08, p: 1.1, c: 0, d: "Минимализм", th: th("#d4d4d4", "#a3a3a3", "#171717", "#fafafa") },
  { id: "gsi", n: "GSI AOSP (Treble)", b: null, r: 0.18, p: 1.05, c: 0, d: "Generic System Image", th: th("#64748b", "#475569", "#0f172a", "#94a3b8") },
  { id: "kerneloc", n: "Custom Kernel + OC", b: null, r: 0.25, p: 1.28, c: 1500, d: "Разгон CPU/GPU", th: th("#f43f5e", "#e11d48", "#4c0519", "#fb7185") },
  { id: "perfmod", n: "Performance Mod", b: null, r: 0.2, p: 1.22, c: 800, d: "Твики производительности", th: th("#f59e0b", "#d97706", "#451a03", "#fcd34d") },
  { id: "battery", n: "Battery Saver ROM", b: null, r: 0.1, p: 0.95, c: 0, d: "Макс. автономность", th: th("#22c55e", "#16a34a", "#052e16", "#bbf7d0") },
  { id: "gaming", n: "Gaming ROM", b: null, r: 0.15, p: 1.2, c: 600, d: "Под игры", th: th("#a855f7", "#7e22ce", "#3b0764", "#e9d5ff") },
  { id: "experimental", n: "Experimental Nightly", b: null, r: 0.35, p: 1.1, c: 0, d: "Нестабильная сборка", th: th("#71717a", "#3f3f46", "#18181b", "#a1a1aa") },
  { id: "brickrisk", n: "Unknown Vendor Dump", b: null, r: 0.55, p: 0.7, c: 0, d: "Свалка — риск кирпича", th: th("#44403c", "#292524", "#0c0a09", "#a8a29e") },
];

export function fmt(n: number) {
  return Math.round(n).toLocaleString("ru-RU") + " ₽";
}

export function r100(n: number) {
  return Math.round(n / 100) * 100;
}

export function rnd<T>(a: readonly T[]): T {
  return a[Math.floor(Math.random() * a.length)];
}

export function pname(p: { brand: string; model: string }) {
  return p.brand + " " + p.model;
}

export function baseTier(base: number) {
  return base > 45000 ? 3 : base > 20000 ? 2 : base > 9000 ? 1 : 0;
}

export function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}
