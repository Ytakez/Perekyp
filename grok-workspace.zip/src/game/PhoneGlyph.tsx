import { finishFor, hex, layoutFor } from "./layout";
import type { Phone } from "./types";

export function PhoneGlyph({ phone }: { phone: Phone }) {
  const L = layoutFor(phone.brand, phone.model, phone.base);
  const f = finishFor(phone.brand, phone.model, phone.color);
  const cracked = phone.c === 3 || phone.d.s >= 1;
  return (
    <div className="phone-mini" style={{ background: hex(f.glass), borderColor: hex(f.frame) }}>
      {L.cam.shape === "bar" ? <span className="cam-bar" style={{ background: hex(f.frame) }} /> : null}
      {L.hinge ? <span className="cam-hinge" /> : null}
      {L.cam.lenses.slice(0, 4).map((lens, i) => (
        <span
          key={i}
          className="lens"
          style={{
            left: `${((lens.x + L.w / 2) / L.w) * 100}%`,
            top: `${((L.h / 2 - lens.y) / L.h) * 100}%`,
            width: `${Math.max(12, (lens.r / L.w) * 2 * 100)}%`,
            boxShadow: L.poco ? `0 0 0 1.5px ${hex(f.accent)}` : undefined,
          }}
        />
      ))}
      {phone.d.b ? <span className="swell" /> : null}
      {cracked ? <span className="crack" /> : null}
    </div>
  );
}
