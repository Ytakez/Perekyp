import { createFileRoute } from "@tanstack/react-router";
import { Boot } from "@/game/Game";

export const Route = createFileRoute("/")({ component: Boot });
